---
name: prd-to-prompt
description: PRD 转 Prompt 优化工具。当用户提到「优化 prompt」「PRD 转 prompt」「需求文档转指令」「prompt 太长/效果差」「帮我拆解需求」「把 PRD 变成 AI 指令」时触发。核心解决：直接把 PRD 大段文字搬运作为 AI 指令导致的 prompt 表述不精准、生成效果偏差问题。通过 2 步处理：Step 1 解析 PRD 输出需求框架 → Step 2 一次性生成全部结构化 Prompt。
---

# PRD Prompt 优化器

## 使用记录（启动时静默执行）

Skill 触发后，**立即**执行以下命令记录本次调用（失败不影响主流程）：

```bash
python3 ~/.claude/skills/prd-prompt-optimizer/scripts/main.py 2>&1
```

从输出中提取 `[KU_RECORD_ID] recXXXX` 并记住 `record_id`，供收尾满意度采集使用。若失败或无输出，`record_id` 置为空，跳过满意度采集。

---

将冗长的 PRD 需求文档，通过 2 步方法，转化为高质量、结构化的 AI 指令集合。每步先输出结果再等用户确认，全程保持用户可控。

## 输入方式

支持以下三种 PRD 输入方式：
- **粘贴文字**：直接将 PRD 内容粘贴到对话中
- **Ku 链接**：提供 `ku.baidu-int.com` 文档链接，自动用 ku-operator skill 读取
- **附件文件**：上传 Word/PDF 等文档

## 2 步工作流程

详细的解析维度和精炼规则见 `references/step-guide.md`，输出模板见 `assets/prompt-template.md`。

---

### Step 1 / 2：PRD 解析 → 需求框架

读取用户提供的 PRD，按以下 6 个维度提取关键信息：

- **产品目标**：解决什么问题
- **用户角色**：Who + 核心诉求
- **核心功能列表**：按 P0 / P1 / P2 优先级排列
- **关键交互路径**：主流程状态流转
- **边界条件**：权限、数据边界、异常场景
- **非功能约束**：性能、安全、兼容性

输出「需求框架摘要」后询问：
> 「Step 1/2 完成 ✓ 以上是我对 PRD 的结构化理解，共识别到 N 个功能模块。有偏差请告诉我，确认后直接生成全部 Prompt。」

---

### Step 2 / 2：一次性生成全部 Prompt

用户确认框架后，**不再分步**，一次性输出完整的 Prompt 集合，包含：

**① 全局框架 Prompt（1 条）**

涵盖：产品定位 + 目标用户 + 整体功能范围 + 核心约束。

精炼原则（详见 `references/step-guide.md` 精炼词汇表）：
- 删除无约束价值的形容词（"友好的"、"合理的"、"高效的"）
- 模糊表述替换为具体描述或数值
- 保留高语义密度词汇（技术名词、角色名、数据字段名）

**② 功能模块 Prompt 列表（每个功能 1 条）**

每条遵循五要素结构：
```
【场景】在什么情况下
【角色】谁（具体角色名，非泛称"用户"）
【行为】要做什么操作
【预期输出】产出格式/内容/状态描述
【约束条件】不能做什么 / 数据边界 / 权限 / 异常处理
```

按 P0 → P1 → P2 顺序排列，每条标注适用阶段：
- `[原型生成]`：用于 Figma Make / 低代码工具
- `[代码生成]`：用于 Comate / Cursor 等 AI IDE
- `[评审校验]`：用于代码评审 / 设计走查

输出完成后询问：
> 「Step 2/2 完成 🎉 共生成 1 条全局 Prompt + N 条功能 Prompt。是否保存到 Ku 知识库？提供目标链接即可，或我直接保存到你的个人知识库。」

---

## 注意事项

- 若用户提供 Ku 链接，先调用 `ku-operator` skill 读取文档内容，再进入 Step 1
- 若 PRD 超过 500 行，先 Grep 定位核心章节，避免全量加载
- Step 1 结束必须等用户确认，Step 2 不再拆分，一次全部输出

## 满意度采集（完成后必须执行）

完成交付后，**立即**发送满意度提示：

1. 从脚本 stderr 输出中找到 `[KU_RECORD_ID] recXXXXX` 行，提取 `record_id`
2. 在回复末尾追加以下固定格式的满意度提示：

```
---
**结果有帮助吗？直接回复数字即可：**
> **1** 👍 有帮助　　**2** 👎 没帮助
---
```

3. 用户回复 `1` 或 `2` 后，执行对应命令：

```bash
python3 ~/.claude/skills/prd-prompt-optimizer/scripts/update_satisfaction.py --record-id <record_id> --value "1"
python3 ~/.claude/skills/prd-prompt-optimizer/scripts/update_satisfaction.py --record-id <record_id> --value "2"
```

> 若 stderr 中无 `[KU_RECORD_ID]` 行，或命令执行失败，静默跳过，不影响交付流程。
