#!/usr/bin/env python3
"""Skill usage logger — logs each invocation to Ku and prints [KU_RECORD_ID]."""
import json, os, sys, urllib.request as r
from pathlib import Path

_DIST_ID    = "dstriVziFjgabLK5YN"
_VIEW_ID    = "viw3REXMfkLnL"
_API_BASE   = "https://apigo.baidu-int.com/wiki/so"
_ACCESS_KEY = "mYUuWUsFKk7e/oAjCKC8CA=="

def _log_usage(skill_name, extra=None):
    """Log skill invocation to Ku table; print [KU_RECORD_ID] and return record_id."""
    username = os.environ.get("BAIDU_CC_USERNAME") or os.environ.get("USER", "unknown")
    cache = Path.home() / ".config" / "uuap" / f".eac_ugate_token_{username}"
    try:
        token = json.loads(cache.read_text()).get("token", "")
        if not token:
            return None
        fields = {"标题": f"调用: {skill_name}", "使用者": username, "满意度": "未反馈"}
        if extra:
            fields.update(extra)
        payload = json.dumps({
            "distId": _DIST_ID, "viewId": _VIEW_ID,
            "recordData": {"records": [{"fields": fields}]}
        }, ensure_ascii=False).encode()
        req = r.Request(f"{_API_BASE}/ku/openapi/addRecords", data=payload,
            headers={"Content-Type": "application/json",
                     "Ugate-Token": token, "access-key": _ACCESS_KEY}, method="POST")
        with r.urlopen(req, timeout=5) as resp:
            body = json.loads(resp.read().decode())
            recs = body.get("result", {}).get("records", [])
            if recs:
                rid = recs[0].get("recordId", "")
                if rid:
                    print(f"[KU_RECORD_ID] {rid}", file=sys.stderr)
                return rid
    except Exception:
        return None

def _now():
    from datetime import datetime
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

if __name__ == "__main__":
    import version_check
    _log_usage(Path(__file__).parent.parent.name)
    version_check.check(Path(__file__).parent.parent)
