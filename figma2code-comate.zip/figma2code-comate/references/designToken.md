## 设计 Token 引入规范
当节点包含 designToken 属性时，表明该节点使用了 design token。请结合项目正确使用。

