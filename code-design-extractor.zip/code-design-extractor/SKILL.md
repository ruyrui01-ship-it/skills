---
name: code-design-extractor
description: "Extract design tokens and generate design system documentation from a frontend codebase — no Figma file required. Produces: token.json (W3C format), src/styles/theme.css, guidelines/tokens.md, guidelines/components.md. Use when the user wants to: (1) reverse-engineer design tokens from an existing codebase, (2) document a design system that lives only in code, (3) standardize scattered hardcoded values into a maintainable token system, (4) optionally sync extracted tokens into a Figma Variable Collection for designer use. Does NOT require a Figma file to run. figma-use skill is only needed for the optional Figma sync step."
---

# Code Design Extractor

Extract design tokens and design system guidelines from a frontend codebase.
For teams whose design decisions live in code, not in a Figma file.

## Output Structure

```
token.json                  ← Structured design tokens (W3C format)
src/styles/theme.css        ← CSS custom properties from extracted values
guidelines/
├── tokens.md               ← Token reference table + DO/NEVER rules
└── components.md           ← Component patterns and prop conventions
```

No Guidelines.md entry point, no setup.md — this skill documents an existing system,
it does not configure a new one. Those files belong to figma-make-kit.

---

## Step 1: Gather Frontend Standards

Run this step before scanning the codebase. Standards constrain both **where to look**
and **how to format** the output.

**If the user provides a standards file** (`.md`, `.mdr`, or pasted text): read and extract:
- Component library and version
- Style approach (CSS Modules / Tailwind / styled-components / other)
- File naming convention (PascalCase / kebab-case)
- Existing token naming convention (if any)

**If the user has no standards file**, send a single message asking all questions at once:
> Read `references/standards-questions.md` for the exact question set to use.

Must confirm before proceeding to Step 2:
- Component library + version (determines which theme object to locate)
- Style approach (determines where token values are likely defined)

Infer reasonable defaults when the user says "standard setup" or similar.

### How standards affect the scan

| Standard | Scan implication |
|----------|-----------------|
| Tailwind | Look for `tailwind.config.*` → `theme.extend` |
| CSS Modules | Look for `:root` in `globals.css` / `variables.css` |
| styled-components | Look for `ThemeProvider` and theme object files |
| antd v5 | Look for `ConfigProvider` `token:` block |
| antd v4 | Look for Less variable override files (`*.less`, `theme.js`) |
| MUI | Look for `createTheme()` calls |

---

## Step 2: Scan Codebase — Locate Token Sources

Search the repository in priority order. Stop at the first tier that yields
meaningful design values; record all tiers found for Step 3.

### Tier 1 — Dedicated token files (most reliable)

Look for:
- `tokens.css`, `variables.css`, `design-tokens.css` — CSS custom properties
- `token.json`, `tokens.json`, `design-tokens.json` — JSON token definitions
- `style-dictionary.config.*`, `sd.config.*` — Style Dictionary source files
- Any file in a directory named `tokens/`, `design-system/`, or `theme/`

If found: these are the authoritative source. Extract directly, skip lower tiers for the
same category.

### Tier 2 — Global style entry point

Look for:
- `globals.css`, `index.css`, `app.css`, `main.css`
- `:root { }` blocks containing CSS custom properties

Extract all `--*` variables and their values.

### Tier 3 — Framework/library theme configuration

Based on the component library identified in Step 1:

- **Tailwind**: parse `tailwind.config.js/ts` → `theme.extend` block
  - Map `colors` → `color` category
  - Map `spacing` → `spacing` category
  - Map `borderRadius` → `radius` category
  - Map `fontSize`, `fontWeight`, `lineHeight` → `typography` category
- **antd v5**: find `ConfigProvider` `token:` object → map to token categories
- **antd v4**: find Less variable files or `theme.js` → map to categories
- **MUI**: find `createTheme({ palette, typography, spacing, shape })` → map to categories
- **styled-components**: find theme object passed to `ThemeProvider` → map to categories

### Tier 4 — Component source files (fallback, least reliable)

Use only when Tiers 1–3 yield fewer than 5 tokens in a category.

1. Glob all component files: `src/**/*.tsx`, `src/**/*.jsx`, `src/**/*.css`, `src/**/*.module.css`
2. Collect all unique design values per category:
   - Colors: hex values, rgb/rgba, named colors
   - Spacing/sizing: px values in padding, margin, gap, width, height
   - Radius: px/% values in border-radius
   - Typography: font-size, font-weight, line-height values
3. Frequency threshold: values appearing in **3 or more files** → candidate tokens
4. Flag ambiguous cases (e.g., two similar blues at `#1677ff` and `#1890ff`) for user
   clarification in Step 3

### Scan summary

After scanning, present a brief summary to the user before extracting:

```
发现的 token 来源：
- Tier 1: src/styles/variables.css (32 个 CSS 变量)
- Tier 3: tailwind.config.ts (colors, spacing)
- Tier 4 未启用（Tier 1 已覆盖所有类别）

共识别约 XX 个候选 token，将提取为 6 个类别。
```

---

## Step 3: Extract and Structure → token.json + theme.css

### 3a: Resolve conflicts between tiers

If the same semantic value appears in multiple tiers, use this precedence:
**Tier 1 > Tier 2 > Tier 3 > Tier 4**

If values conflict (e.g., Tier 2 CSS var is `#1677ff` but Tier 3 antd token is `#165dff`),
note the discrepancy and ask the user which is authoritative before writing output.

### 3b: Name tokens

- **If existing names are found** (CSS var names, Tailwind key names): preserve them exactly.
  Do not rename a variable named `--brand-blue` to `--color-brand-primary`.
- **If values have no names** (Tier 4 frequency inference): propose names following the
  pattern `--{category}-{role}-{scale}` and confirm with the user via a brief summary
  (not a full list) before generating files.
- Flag any ambiguous values (two similar blues, inconsistent spacing scale) and ask user
  to clarify semantic intent before naming.

### 3c: Generate token.json

W3C Design Token format, grouped by category: `color`, `typography`, `spacing`,
`radius`, `shadow`, `motion`.

> Read `references/output-templates.md` for the exact format.

### 3d: Generate src/styles/theme.css

CSS custom properties derived from token.json values.

Rules:
- Use HEX values — do NOT convert to oklch (oklch breaks component library theme APIs)
- Add a file header comment: `/* Auto-generated by code-design-extractor. */`
- Group variables by category with section comments
- If component library is antd v5: also generate `src/styles/theme.config.ts` with
  `ConfigProvider` token mapping
- If component library is antd v4: note Less variable override equivalents in comments
- If component library is MUI: note `createTheme()` mapping in comments

> Read `references/output-templates.md` for theme.css and theme.config.ts format examples.

---

## Step 4: Generate guidelines/ Documents

### tokens.md

For each token category, generate a table and usage rules:

```
| Token | Value | Usage context |
```

Include per category:
- DO / NEVER code examples using the project's actual style approach (from Step 1)
- Special handling notes (unitless font-weight values, shadow shorthand, etc.)
- Note tokens inferred from Tier 4 as: "⚠ Inferred from frequency — confirm with your team"

### components.md

Infer component patterns from the codebase:

1. Glob component files matching user's naming convention
2. For each component, identify:
   - Which library component it wraps or uses directly (from import statements)
   - What props it exposes
   - Which tokens it references (CSS vars used in its style file)
3. Generate a component table: Component name | Library base | Key props | Token usage
4. Include composition rules: when to wrap vs use directly

Do NOT fabricate component behavior. Only document what is found in the files.

---

## Optional Step 5: Sync to Figma Variable Collection

**Trigger**: user explicitly says "sync to Figma", "add to Figma", or "create a Figma library".
Do NOT suggest or run this step unless the user requests it.

**Purpose**: give designers a Figma Variable Collection that matches the tokens in code.
This is a one-time setup for design collaboration — it does not create a code generation loop.

1. Invoke `figma-use` skill, then call `use_figma` to:
   - Create a Variable Collection named "Design Tokens"
   - Create one mode: "Default"
   - Create variables per category with correct Figma scopes:
     - `color` → scope: `ALL_SCOPES` (or `FRAME_FILL`, `TEXT_FILL` as appropriate)
     - `spacing` → scope: `GAP`, `WIDTH_HEIGHT`
     - `radius` → scope: `CORNER_RADIUS`
     - `typography` sizes → scope: `FONT_SIZE`
2. Create a reference frame "Token Reference" with:
   - Color swatches grid
   - Typography scale samples
   - Spacing scale visualization
3. Return the Figma file URL to the user

This step requires a Figma file URL. If the user has no existing file, ask whether to create
a new one before proceeding.

---

## Step 6: Validate Output

- [ ] token.json covers all 6 categories (or notes which are absent and why)
- [ ] All CSS variables in theme.css have a corresponding entry in token.json
- [ ] No hardcoded values in theme.css (all values come from extracted token data)
- [ ] tokens.md examples use the project's actual style approach (not generic CSS)
- [ ] components.md only documents components found in the codebase — nothing fabricated
- [ ] Tier 4 inferred tokens are flagged with ⚠ in tokens.md
- [ ] Conflicted values were resolved with user confirmation before output

---

## Conditional Paths

| Situation | Action |
|-----------|--------|
| User provides standards file | Extract from file; skip standards questions |
| No standards file | Ask all questions in a single message (see references/standards-questions.md) |
| Tier 1 token files found | Extract directly; Tier 4 scan not needed |
| Only Tier 4 available | Run frequency analysis; confirm inferred names with user before writing |
| Conflicting values across tiers | Ask user to designate authoritative source before proceeding |
| Ambiguous values (two similar blues) | Ask user to clarify semantic intent before naming |
| User only wants token.json + theme.css | Skip Step 4 (guidelines) |
| User only wants documentation | Run Steps 1–2, skip token.json generation, go straight to Step 4 |
| User wants Figma sync | Run Step 5 after Step 3; requires Figma file URL |
| No Figma account / no file | Step 5 is optional — skip without impact on main output |
| antd v5 detected | Also generate src/styles/theme.config.ts after theme.css |
| Tailwind detected | Note potential variable-vs-utility tension in tokens.md; respect user's choice |
