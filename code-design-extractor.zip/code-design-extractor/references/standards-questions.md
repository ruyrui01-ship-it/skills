# Frontend Standards Questions — code-design-extractor

When the user has no standards file, ask all of the following in a single message.
Purpose: understand the tech stack so we know **where to look** and **how to format** output.

---

> 在开始扫描之前，我需要了解你的前端技术栈，这样才能找对 token 的位置，并按你现有的规范整理文档：
>
> 1. **组件库**：你使用哪个组件库？（antd v5 / antd v4 / MUI / shadcn/ui / 无 / 其他）
> 2. **样式方案**：样式怎么写？（CSS Modules / Tailwind / styled-components / 其他）
> 3. **有没有现成的 token 文件**：比如 `variables.css`、`tokens.json`、`tailwind.config.ts` 等？有的话告诉我路径，没有也没关系。
> 4. **token 命名习惯**：已有的 CSS 变量或 Tailwind key 是什么风格？（比如 `--color-primary`、`--brand-blue`、`primary`，或者"没有，都是硬编码"）
> 5. **代码仓库路径**：我应该从哪个目录开始扫描？（默认从 `src/` 开始）
>
> 如果某项不确定，直接说"不知道"就好。

---

## Minimum Required to Proceed

Must confirm before Step 2:
- Component library (determines which theme object to locate in Tier 3 scan)
- Style approach (determines where CSS variable definitions are likely to be)

## Inference Rules

- User says "standard antd" with no version → assume **v5**
- User says "Tailwind" → Tier 3 scan targets `tailwind.config.*`; note in tokens.md that
  utilities and CSS vars may coexist
- User says "no token files" or "all hardcoded" → skip Tier 1 and Tier 2; go straight to
  Tier 3 (framework config) then Tier 4 (frequency analysis)
- User says "standard React project" or "CRA" with no other info → assume CSS Modules,
  no component library; scan for `:root` variables and component hardcodes
- User says "Next.js" → start scan from `app/` or `src/` depending on project structure;
  note that server components cannot use CSS-in-JS at runtime
- User doesn't know their component library → search `package.json` dependencies first
  and infer from there before asking again
