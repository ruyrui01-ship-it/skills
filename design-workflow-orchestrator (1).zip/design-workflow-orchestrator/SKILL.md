---
name: design-workflow-orchestrator
description: AI 产品设计研发智能工作流编排器。当用户说"生成产品demo"、"我要做一个产品原型"、"帮我做个设计原型"、"做一个XXX产品"时触发，引导用户选择资源类型并自动编排设计工作流。也支持用户直接上传Figma文件/输入模糊需求/上传PRD文档/输入代码仓库地址时的直接路由。自动串行调度 vibe-coding-setup、figma-make-kit、requirement-intake、prd-prompt-optimizer、design-demo-engineer 五个子Skill。
---

# Design-Workflow-Orchestrator

## 核心交互规范（最高优先级）

**所有需要用户做选择的节点，必须调用 `ask_user_question` 工具弹出选项卡片，严禁用纯文字列表替代。** 这是用户体验的核心要求：用户需要看到可点击的选项卡片，而不是阅读文字后手动回复 A/B/C。

- 凡流程中出现"请选择"、"是否…"、"你想如何…"等决策点 → 必须调用 `ask_user_question`
- 如果 `ask_user_question` 调用失败，**重试一次**，仍失败再提示用户（不允许直接降级为文字列表）
- 唯一例外：引导用户在终端执行命令（如 `cd`），此类操作指引可以用加粗文字输出

### ask_user_question 调用规范（防止解析失败）

**`prompt` 字段必须是单行纯文字，禁止使用 `\n` 换行符。** 多行信息应整合为一句话，或将上下文信息放到对话文本中先输出，再调用工具。示例：

```
// 错误 ❌ —— \n 会导致 JSON 非法，工具报 "must be a non-empty array"
"prompt": "检测到仓库：\n  ./foo/bar\n\n是否进入？"

// 正确 ✅ —— 单行，关键信息用括号/顿号内联
"prompt": "检测到子目录仓库 ./foo/bar（远程 icode.baidu.com/...），是否进入继续？"
```

其他字段（`id`、`label`、`title`）同样不得包含 `\n`，保持单行。

---

产品设计研发智能工作流编排器。完整工作流分**三个强制串行阶段**：

- **阶段 0（必选）**：自动检测本地代码环境 → 无环境时调用 vibe-coding-setup（**用户提供仓库URL后必须调用 vibe-coding-setup，禁止自行执行 git 命令**）
- **阶段 1（可选）**：设计系统准备 — 有 Figma 设计稿时提取 Token 和组件规范
- **阶段 2（必选）**：需求结构化 — 用 requirement-intake 或 prd-prompt-optimizer 生成精准设计 Prompt
- **阶段 3（必选）**：Demo 生成 — design-demo-engineer 生成高质量交互原型 + Tweaks 多方案

---

## 一、完整工作流全景

```
用户触发设计工作流意图
         │
         ▼
【第一步：自动检测本地代码环境（必做，无需询问）】
  运行检测：git status / git remote -v / git fetch --dry-run
         │
         ├── 检测到有效环境（Git仓库 + 远程地址 + 分支已同步）
         │         │
         │         └──► 跳过代码环境阶段，直接进入第二步
         │
         └── 无有效环境（无Git仓库 / 无远程地址 / 分支未同步）
                   │
                   ▼
         ask_user_question：代码环境选择
         ┌──────────────────────────────┐
         │ A. 拉取已有代码仓库（输入URL）│
         │ B. 初始化全新项目             │
         │ C. 跳过，直接生成Demo         │
         └──────────────────────────────┘
                   │
            A 或 B │
                   ▼
         调用 vibe-coding-setup
         （克隆仓库 / 初始化项目 / 安装依赖 / 启动开发服务器）
                   │
                   ▼
【第二步：Demo 生成方式选择（ask_user_question）】
         │
         ├── 有 Figma 设计稿 ──► figma-make-kit → 提取 Token/组件规范
         │                              │
         │                              ▼ 询问后续需求输入方式
         │
         ├── 有 PRD 文档 ──────► prd-prompt-optimizer（5步解析）
         │
         └── 只有想法 ──────────► requirement-intake（需求拆解）
                   │
         （以上三路最终都汇入结构化 Prompt）
                   │
                   ▼
【第三步：统一收尾（固定）】
         调用 design-demo-engineer
         （注入：结构化Prompt + 设计Token（如有）+ Tweaks配置）
                   │
                   ▼
         最终设计成果交付
```

---

## 二、灵活入口（用户可从任意节点进入）

除主流程外，用户直接提供特定资源时，从对应节点入口进入，**完成该节点后继续后续工作流**。

### 入口 A：主意图入口（通用，最常见）

**触发信号**：用户说"生成产品demo"、"做一个产品原型"、"帮我设计一个产品"、"我要做个XXX"等意图表达。

**执行逻辑**：严格按「第一步 → 第二步 → 第三步」全流程执行。

---

### 入口 B：代码环境直接入口

**触发信号**：用户提供代码仓库URL、说"基于这个仓库开发"、"克隆这个仓库"、"帮我搭环境"、"本地启动"等。

**执行逻辑**：
1. **必须调用 `vibe-coding-setup` skill**（严禁自行执行 git clone 或任何 git 命令）
2. 将用户提供的仓库URL或克隆命令完整传递给 `vibe-coding-setup`，由其负责所有代码环境配置操作
3. `vibe-coding-setup` 完成后，**继续**进入第二步（Demo 生成方式选择）
4. 执行第三步 design-demo-engineer

> **强制约束**：一旦用户提供了仓库URL或 git clone 命令，无论任何情况都不得跳过 `vibe-coding-setup`，不得自行执行 git 命令。

执行前告知：
```
🔧 检测到代码环境配置需求，启动开发环境准备...
执行路径：vibe-coding-setup → [Demo生成选择] → design-demo-engineer
```

---

### 入口 C：Figma 直接入口

**触发信号**：用户上传或提供 Figma URL，明确表示要提取设计系统（"提取 Token""生成设计规范""上传设计稿"等）。

**执行逻辑**：
1. 直接调用 `figma-make-kit`
2. 完成后询问需求输入方式（PRD 还是想法）
3. 执行对应 Phase 2 → 最终 design-demo-engineer

执行前告知：
```
🎨 检测到 Figma 设计稿，启动设计系统提取...
执行路径：figma-make-kit → [需求输入] → design-demo-engineer
```

---

### 入口 D：PRD 直接入口

**触发信号**：用户上传 PRD 文档/粘贴大段需求文字(>300字含功能描述)/提供 Ku 链接，并表示要生成 Demo。

**执行逻辑**：
1. 直接调用 `prd-prompt-optimizer`
2. 完成后自动流转 `design-demo-engineer`

执行前告知：
```
📄 检测到 PRD 文档，启动需求解析...
执行路径：prd-prompt-optimizer → design-demo-engineer
```

---

### 入口 E：模糊需求直接入口

**触发信号**：用户直接输入粗糙 prompt，如"做一个创意交友 App"、"帮我做个工单系统"，无附件，无 URL。

**执行逻辑**：
1. 判断 prompt 清晰度（见三、2 判断规则）
2. 不明确 → 调用 `requirement-intake` → `design-demo-engineer`
3. 明确 → 跳过 requirement-intake，直接进入 `design-demo-engineer`

---

## 三、第一步：代码环境检测详细规范

### 3.1 检测项目与命令

**按以下顺序静默执行（不向用户展示命令输出）**：

```bash
# 检测1：当前目录是否在Git仓库内
git rev-parse --is-inside-work-tree 2>/dev/null

# 若检测1失败（当前目录非git仓库），执行检测2：
# 检测2：在工作区目录下递归搜索子目录中的git仓库（最深4层）
find . -name ".git" -maxdepth 4 -type d 2>/dev/null

# 若检测1成功，继续执行：
# 检测3：是否配置了远程地址
git remote -v 2>/dev/null

# 检测4：当前分支与远程是否同步
git fetch --dry-run 2>/dev/null
git status -sb 2>/dev/null
```

> **重要**：工作区目录指 Comate 当前打开的项目根目录（即 workspace path），而非系统根目录。find 命令必须在该目录下执行，不得在 / 或 ~ 下执行。

### 3.2 环境状态判断矩阵

| 状态 | 当前目录git仓库 | 子目录有git仓库 | 远程地址 | 分支同步 | 处理方式 |
|------|---------|---------|---------|---------|---------|
| ✅ 完整环境 | ✅ | - | ✅ | ✅ 最新 | 跳过环境配置，进入第二步 |
| ⚠️ 部分环境 | ✅ | - | ✅ | ❌ 落后 | 询问是否 pull 更新，然后进入第二步 |
| ⚠️ 无远程 | ✅ | - | ❌ | - | 按「无有效环境」处理 |
| 🔍 子目录有仓库 | ❌ | ✅ | - | - | 展示找到的仓库路径，询问用户是否进入（见 3.4） |
| ❌ 无环境 | ❌ | ❌ | - | - | 询问用户选择（见下方 3.3 卡片） |

### 3.3 无环境时的用户选择卡片

当检测结果为「无有效环境」时，调用 `ask_user_question`（注意：label 中避免 emoji，防止工具解析失败）：

```json
{
  "title": "未检测到本地代码环境",
  "questions": [
    {
      "id": "code_env_choice",
      "prompt": "当前目录没有代码仓库，你想如何开始？",
      "options": [
        { "id": "clone_repo",  "label": "拉取已有代码仓库（请提供仓库 URL）" },
        { "id": "new_project", "label": "初始化全新项目（从零开始）" },
        { "id": "skip_env",    "label": "跳过，直接生成设计 Demo" }
      ]
    }
  ]
}
```

| 用户选择 | 后续路径 |
|---------|---------|
| `clone_repo` | 请用户输入仓库URL或粘贴克隆命令 → **强制调用 `vibe-coding-setup` skill**（禁止自行执行任何 git 命令）→ 进入第二步 |
| `new_project` | **强制调用 `vibe-coding-setup` skill**（初始化模式）→ 进入第二步 |
| `skip_env` | 直接进入第二步，跳过代码环境配置 |

> **重要**：`clone_repo` 和 `new_project` 两种选择都必须通过调用 `vibe-coding-setup` skill 来完成，Orchestrator 自身绝对不能执行 git clone、git init 等任何代码环境配置命令。

### 3.4 在子目录发现 Git 仓库时的处理

当「当前目录非 git 仓库」但「子目录中 find 找到了 .git」时，**必须调用 `ask_user_question`** 告知用户并询问意图：

假设找到了路径如 `./baidu/sec-llm-fe/llm-copilot-xdr`（可能有多个），调用 `ask_user_question`（label 中避免 emoji，**prompt 必须单行，禁止 `\n`**）：

```json
{
  "title": "在子目录中找到了代码仓库",
  "questions": [
    {
      "id": "subdir_repo_choice",
      "prompt": "检测到子目录仓库 ./baidu/sec-llm-fe/llm-copilot-xdr（远程：icode.baidu.com/baidu/sec-llm-fe/llm-copilot-xdr），是否进入该仓库继续工作流？",
      "options": [
        { "id": "enter_repo", "label": "进入该仓库，继续生成 Demo" },
        { "id": "skip_env",   "label": "不需要，跳过直接进入 Demo 生成" },
        { "id": "clone_repo", "label": "拉取其他仓库（请提供 URL）" }
      ]
    }
  ]
}
```

**若找到多个 git 仓库**，先用对话文本逐行列出所有路径（不要放进 prompt 字段），然后调用 `ask_user_question`，将 prompt 改为简单单行文字（如 `"请选择要进入的仓库序号，或直接跳过"`），并将选项中的「进入该仓库」替换为「选择某个仓库（请输入序号或路径）」，等用户回复后继续。

| 用户选择 | 后续路径 |
|---------|---------|
| `enter_repo` | 输出 cd 引导提示（见下方）→ 等用户确认已进入 → 检测 remote + 分支同步状态（同 3.2）→ 进入第二步 |
| `skip_env` | 直接进入第二步，跳过代码环境 |
| `clone_repo` | 请用户输入 URL → 调用 `vibe-coding-setup` → 进入第二步 |

**用户选择 `enter_repo` 后，必须先输出如下引导（加粗显示，格式如下），等用户回复确认后再继续**：

> **请在你的终端中执行以下命令，进入该仓库目录：**
>
> **`cd <仓库相对路径>`**（例如：`cd baidu/sec-llm-fe/llm-copilot-xdr`）
>
> **完成后请回复「已进入」或直接继续输入，我会接着推进工作流。**

注意：AI 无法控制用户的终端会话，`cd` 必须由用户手动执行。收到用户确认后，再检测分支状态并进入第二步。

---

## 四、第二步：Demo 生成方式选择

代码环境就绪（或跳过）后，调用 `ask_user_question`（label 中避免 emoji）：

```json
{
  "title": "好的，接下来生成产品 Demo",
  "questions": [
    {
      "id": "resource_type",
      "prompt": "请选择你的资源类型：",
      "options": [
        { "id": "has_figma", "label": "上传 Figma 设计稿，提取设计系统" },
        { "id": "has_prd",   "label": "我有 PRD 需求文档" },
        { "id": "has_idea",  "label": "只有一个想法，帮我拆解需求" }
      ]
    }
  ]
}
```

| 用户选择 | 后续执行路径 |
|---------|------------|
| `has_figma` | → figma-make-kit → 询问（PRD还是想法）→ prd-prompt-optimizer / requirement-intake → design-demo-engineer |
| `has_prd` | → 直接 prd-prompt-optimizer → design-demo-engineer |
| `has_idea` | → 输出文字提示引导输入 → requirement-intake → design-demo-engineer |

#### 用户选择 `has_idea` 后的引导输入步骤

用户选择第三项后，**禁止再次调用 `ask_user_question`**，改为直接输出以下文字提示：

```
好的！请直接在输入框中描述你想做的产品，例如：

  「做一个面向年轻人的创意交友 App，支持兴趣匹配和实时聊天」
  「做一个企业内部工单审批系统，支持多级审批和状态追踪」

请输入简单需求描述 ↓
```

用户回复后，将用户输入直接传入 `requirement-intake` 开始需求拆解，无需再次确认。

---

## 五、第三步：统一收尾（固定调用 design-demo-engineer）

第二步完成后，自动流转至 `design-demo-engineer`。执行前调用 `ask_user_question` 最终确认（label 中避免 emoji）：

```json
{
  "title": "准备生成 Demo",
  "questions": [
    {
      "id": "demo_confirm",
      "prompt": "需求和设计规范已就绪，确认后开始生成 Demo",
      "options": [
        { "id": "go",     "label": "开始生成 Demo + Tweaks 多方案" },
        { "id": "review", "label": "先查看需求清单，确认后再生成" },
        { "id": "stop",   "label": "暂不生成 Demo，先保存需求" }
      ]
    }
  ]
}
```

**传参合并注入**：
- Phase 2 产出的结构化 Prompt / 需求 YAML
- Phase 1 产出的 designTokenPath（如有）
- 用户在 requirement-intake 中配置的 tweaks_config

---

## 六、场景识别规则

### 6.1 场景优先级表

| 优先级 | 场景ID | 命中条件 | 入口类型 |
|--------|--------|---------|---------|
| P1 | SCENE_GUIDE | 用户表达"做demo/原型/产品设计"意图，无具体资源 | 入口A（主流程） |
| P2 | SCENE_CODE_ENV | 用户提供仓库URL / 说"克隆""搭环境""本地启动"等 | 入口B（代码环境） |
| P3 | SCENE_FIGMA | 检测到 Figma URL 或明确上传 Figma 文件 | 入口C（Figma） |
| P4 | SCENE_PRD | 检测到文档附件/Ku链接/大段需求文字(>300字)/提及"PRD" | 入口D（PRD） |
| P5 | SCENE_FUZZY | 仅短文字描述(<200字)，无附件，无URL，无明确PRD关键词 | 入口E（模糊需求） |
| P6 | SCENE_UNKNOWN | 以上均不满足，置信度<0.60 | 兜底 |

### 6.2 Prompt 清晰度判断规则（SCENE_FUZZY 内部）

满足以下 **2项以上** 视为**不明确**，触发 `requirement-intake`：

| 判断项 | 不明确信号 |
|--------|----------|
| 字数 | < 30字 |
| 缺少目标用户 | 未描述"谁在用" |
| 缺少核心功能 | 仅有产品类型，无具体功能点 |
| 缺少技术/平台 | 未提及 Web/App/H5 等 |
| 缺少场景 | 未说明 B端/C端/工具/娱乐等 |

满足 **3项以上** 直接触发 `requirement-intake`，无需额外确认。

### 6.3 置信度

| 置信度 | 处理方式 |
|--------|---------|
| ≥ 0.85 | 直接路由，执行前告知用户决策 |
| 0.60–0.84 | 展示路由决策，ask_user_question 确认后执行 |
| < 0.60 | 触发 SCENE_UNKNOWN 兜底 |

---

## 七、串行流转进度公示格式

每个阶段开始时必须输出进度条，让用户清晰感知所处步骤：

**完整五阶段链路（含代码环境 + Figma）：**
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 工作流进度
 Step 0 代码环境配置      [✅ 完成]
 Step 1 设计系统提取      [✅ 完成]
 Step 2 需求结构化        [🔄 执行中]
 Step 3 Demo 生成         [⬜ 待执行]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

**跳过代码环境（仅设计链路）：**
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 工作流进度
 Step 0 代码环境          [⏩ 已跳过]
 Step 1 需求结构化        [🔄 执行中]
 Step 2 Demo 生成         [⬜ 待执行]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

最终链路追踪（完成后输出）：
```
执行链路：vibe-coding-setup → figma-make-kit → requirement-intake → design-demo-engineer ✅
```

---

## 八、入参 / 出参规范

```typescript
interface OrchestratorInput {
  userText: string;           // 用户原始文字
  hasFigma: boolean;          // 是否有 Figma 文件/URL
  hasPRD: boolean;            // 是否有 PRD 文档
  hasCodeRepo?: boolean;      // 是否有代码仓库URL
  figmaUrl?: string;          // Figma URL（如有）
  prdContent?: string;        // PRD 内容（如有）
  repoUrl?: string;           // 代码仓库URL（如有）
  sessionContext: {
    codeEnvStatus: 'detected' | 'setup' | 'skipped';  // 代码环境状态
    hasDesignToken: boolean;
    designTokenPath?: string;         // Phase 1 产出路径
    hasStructuredRequirement: boolean;
    structuredRequirement?: object;   // Phase 2 产出内容
    executedSkills: string[];         // 已执行链路
  };
}

interface OrchestratorOutput {
  entryPoint: 'GUIDE' | 'CODE_ENV' | 'FIGMA' | 'PRD' | 'FUZZY'; // 入口类型
  executionChain: string[];   // 实际执行的Skill链路
  phaseOutputs: {
    phase: number;
    skillName: string;
    outputType: string;
    deliverable: string;      // 交付物路径/摘要
  }[];
  confidence: number;
  usedFallback: boolean;
}
```

---

## 九、容错与兜底

### SCENE_UNKNOWN 兜底

```json
{
  "title": "请告诉我你现在的状态",
  "questions": [
    {
      "id": "scene_select",
      "prompt": "你想做什么？",
      "options": [
        { "id": "demo",     "label": "生成产品 Demo / 原型" },
        { "id": "code_env", "label": "配置代码开发环境" },
        { "id": "figma",    "label": "上传 Figma，提取设计系统" },
        { "id": "prd",      "label": "我有 PRD，直接解析出 Prompt" },
        { "id": "idea",     "label": "我只有一个想法，帮我拆解" }
      ]
    }
  ]
}
```

### 子Skill异常处理

| 异常类型 | 处理方式 |
|---------|---------|
| Skill 未安装 | 提示安装命令，暂停流转 |
| vibe-coding-setup 克隆失败 | 展示错误原因，提供重试或跳过选项 |
| Figma 无法读取（私有文件/MCP错误） | 提示用户检查文件权限，跳过 Phase 1 继续 |
| PRD 内容为空 | 提示用户重新上传，等待后继续 |
| requirement-intake 中途放弃 | 保存已收集维度，询问是否直接生成（用已有内容） |
| design-demo-engineer 超时 | 提示分拆需求重试 |

---

## 十、完整调用示例

### 示例 A：主流程 → 无代码环境 → 克隆仓库 → PRD → Demo

```
用户：「生成产品demo」

→ 第一步：静默检测代码环境 → 无Git仓库
→ 展示代码环境选择卡片
→ 用户选择「拉取已有代码仓库」，输入URL
→ 调用 vibe-coding-setup（克隆 + 安装依赖 + 启动服务）
→ 第二步：展示Demo生成方式选择
→ 用户选择「我有PRD」
→ prd-prompt-optimizer（5步解析）
→ 第三步：design-demo-engineer

执行链路：vibe-coding-setup → prd-prompt-optimizer → design-demo-engineer ✅
```

### 示例 B：主流程 → 已有代码环境 → Figma + 想法 → Demo

```
用户：「我要做一个产品原型」

→ 第一步：静默检测代码环境 → 检测到完整Git环境，跳过
→ 第二步：展示Demo生成方式选择
→ 用户选择「上传 Figma 设计稿」
→ figma-make-kit（提取 token.json / theme.css）
→ 询问后续：「只有一个想法」
→ requirement-intake（注入设计Token上下文）
→ 第三步：design-demo-engineer（Token + 需求双注入）

执行链路：figma-make-kit → requirement-intake → design-demo-engineer ✅
```

### 示例 C：代码环境直接入口 → 继续 Demo 生成

```
用户：「帮我克隆这个仓库 https://github.com/xxx/yyy」

→ 入口B直接触发
→ 调用 vibe-coding-setup
→ 完成后自动继续：展示Demo生成方式选择
→ 用户选择「只有一个想法」
→ 输入：「做一个任务看板」
→ requirement-intake
→ design-demo-engineer

执行链路：vibe-coding-setup → requirement-intake → design-demo-engineer ✅
```

### 示例 D：Figma 直接入口 → 接 PRD → Demo

```
用户：「https://figma.com/design/xxx 帮我提取设计规范」

→ 入口C直接触发
→ figma-make-kit 完成
→ 询问后续：「我有PRD」
→ prd-prompt-optimizer（注入Token上下文）
→ design-demo-engineer

执行链路：figma-make-kit → prd-prompt-optimizer → design-demo-engineer ✅
```

### 示例 E：直接上传 PRD → Demo（最短路径）

```
用户：[粘贴500字PRD]「帮我生成设计原型」

→ 入口D，SCENE_PRD 命中
→ prd-prompt-optimizer（5步解析）
→ design-demo-engineer

执行链路：prd-prompt-optimizer → design-demo-engineer ✅
```

### 示例 F：主流程 → 已有代码环境但分支落后 → 询问更新

```
用户：「生成产品demo」

→ 第一步：静默检测 → Git仓库存在，远程已配置，但分支落后 origin/main 3 commits
→ 询问：「检测到本地分支落后远程 3 个提交，是否先拉取最新代码？」
→ 用户确认 → 执行 git pull
→ 第二步：继续Demo生成方式选择
→ ...后续正常流转
```

### 示例 G：主流程 → 当前目录非git仓库 → 子目录中发现仓库 → 确认后继续

```
用户：「生成产品demo」

→ 第一步：静默检测 → 当前目录（test_project_0511/）不是 git 仓库
→ 递归 find .git → 找到 ./baidu/sec-llm-fe/llm-copilot-xdr/.git
→ 展示子目录仓库卡片（路径 + 远程地址）
→ 用户选择「进入该仓库，继续生成 Demo」
→ 输出引导：**请在终端执行 `cd baidu/sec-llm-fe/llm-copilot-xdr`，完成后回复「已进入」**
→ 用户确认已进入 → 检测 remote + 分支状态（master，已同步）
→ Step 0 标记为完成，进入第二步：Demo 生成方式选择
→ ...后续正常流转

执行链路：[子目录仓库检测] → requirement-intake → design-demo-engineer ✅
```

## 满意度采集（完成后必须执行）

完成交付后，**立即**发送满意度提示：

1. 从脚本 stderr 输出中找到 `[KU_RECORD_ID] recXXXXX` 行，提取 `record_id`
2. 在回复末尾追加以下固定格式的满意度提示：

```
---
**结果有帮助吗？直接回复数字即可：**
> **1** 👍 有帮助　　**2** 👎 没帮助
---
```

3. 用户回复 `1` 或 `2` 后，执行对应命令：

```bash
python3 <skill目录>/scripts/update_satisfaction.py --record-id <record_id> --value "1"
python3 <skill目录>/scripts/update_satisfaction.py --record-id <record_id> --value "2"
```

> 若 stderr 中无 `[KU_RECORD_ID]` 行，或命令执行失败，静默跳过，不影响交付流程。
