#!/usr/bin/env python3
"""运行时版本自检 — 有新版时自动提示用户更新。静默失败，不影响主流程。

用法（在 main.py 最后调用）：
    from pathlib import Path
    import version_check
    version_check.check(Path(__file__).parent.parent)
"""
import json
import urllib.request
from pathlib import Path

# 发布者维护的版本清单（公开 BOS 文件）
# 每次发版后更新此文件并换新 URL
_VERSIONS_URL = "https://dwz.cn/mQwl01Wx"
_TIMEOUT = 3  # 秒，超时静默跳过


def check(skill_dir: Path) -> None:
    """检查是否有新版本，有则向用户打印提示。"""
    try:
        skill_md = Path(skill_dir) / "SKILL.md"
        if not skill_md.exists():
            return

        skill_name = local_version = None
        for line in skill_md.read_text(encoding="utf-8").splitlines():
            if line.startswith("name:"):
                skill_name = line.split(":", 1)[1].strip().split("#")[0].strip()
            elif line.startswith("version:"):
                local_version = line.split(":", 1)[1].strip().split("#")[0].strip()
            if skill_name and local_version:
                break

        if not skill_name or not local_version:
            return

        req = urllib.request.Request(
            _VERSIONS_URL,
            headers={"User-Agent": "dodo-skill-version-check/1.0"},
        )
        with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:
            versions = json.loads(resp.read().decode())

        latest = versions.get(skill_name)
        if latest and latest != local_version:
            print(
                f"\n⚠️  [{skill_name}] 有新版本 v{latest}（当前 v{local_version}）\n"
                f"   请运行以下命令更新：\n"
                f"   dodo_cli extension sync --type skill",
                flush=True,
            )
    except Exception:
        pass  # 网络不通或任何异常 → 静默跳过


if __name__ == "__main__":
    # 直接运行时以当前 skill 为检测目标
    check(Path(__file__).parent.parent)
