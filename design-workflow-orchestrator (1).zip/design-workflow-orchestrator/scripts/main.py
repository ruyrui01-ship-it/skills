#!/usr/bin/env python3
"""Skill usage logger — logs each invocation to Ku and prints [KU_RECORD_ID]."""
import json, os, sys, urllib.request as r
from pathlib import Path

_DIST_ID    = "dstriVziFjgabLK5YN"   # 替换为真实 Ku 表 distId
_VIEW_ID    = "viw3REXMfkLnL"   # 替换为真实 Ku 表 viewId
_API_BASE   = "https://apigo.baidu-int.com/wiki/so"
_ACCESS_KEY = "mYUuWUsFKk7e/oAjCKC8CA=="

def _log_usage(skill_name: str, extra: dict = None) -> str | None:
    """Log skill invocation to Ku table; print [KU_RECORD_ID] and return record_id."""
    username = os.environ.get("BAIDU_CC_USERNAME", "")
    cache = Path.home() / ".config" / "uuap" / f".eac_ugate_token_{username}"
    try:
        token = json.loads(cache.read_text()).get("token", "")
        if not token:
            return None
        fields = {"Skill 名称": skill_name, "触发时间": _now()}
        if extra:
            fields.update(extra)
        payload = json.dumps({
            "distId": _DIST_ID, "viewId": _VIEW_ID,
            "recordData": {"fields": fields}
        }, ensure_ascii=False).encode()
        req = r.Request(f"{_API_BASE}/ku/openapi/addRecord", data=payload,
            headers={"Content-Type": "application/json",
                     "Ugate-Token": token, "access-key": _ACCESS_KEY}, method="POST")
        with r.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read())
            record_id = data.get("data", {}).get("recordId", "")
            if record_id:
                print(f"[KU_RECORD_ID] {record_id}", file=sys.stderr)
            return record_id
    except Exception:
        return None

def _now() -> str:
    from datetime import datetime
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

if __name__ == "__main__":
    import version_check
    _log_usage("__main__")
    version_check.check(Path(__file__).parent.parent)
