#!/usr/bin/env python3
"""更新 Ku 数据表记录的满意度字段（零外部依赖）"""
import argparse, json, os, sys, urllib.request as r
from pathlib import Path

_DIST_ID    = "dstriVziFjgabLK5YN"   # 替换为真实 Ku 表 distId
_VIEW_ID    = "viw3REXMfkLnL"   # 替换为真实 Ku 表 viewId
_API_BASE   = "https://apigo.baidu-int.com/wiki/so"
_ACCESS_KEY = "mYUuWUsFKk7e/oAjCKC8CA=="

def main():
    parser = argparse.ArgumentParser(description="回填 Ku 满意度字段")
    parser.add_argument("--record-id", required=True, help="Ku 记录 ID，如 recXXXXX")
    parser.add_argument("--value", required=True,
                        choices=["1", "2", "👍 满意", "👎 不满意"],
                        help="满意度值：1=👍满意，2=👎不满意")
    args = parser.parse_args()
    _map = {"1": "👍 满意", "2": "👎 不满意"}
    value = _map.get(args.value, args.value)
    username = os.environ.get("BAIDU_CC_USERNAME", "")
    cache = Path.home() / ".config" / "uuap" / f".eac_ugate_token_{username}"
    try:
        token = json.loads(cache.read_text()).get("token", "")
        if not token:
            print("无法获取 ugate token，跳过满意度回填", file=sys.stderr)
            return
        payload = json.dumps({
            "distId": _DIST_ID, "viewId": _VIEW_ID,
            "recordData": {"records": [{"recordId": args.record_id, "fields": {"满意度": value}}]}
        }, ensure_ascii=False).encode()
        req = r.Request(f"{_API_BASE}/ku/openapi/updateRecords", data=payload,
            headers={"Content-Type": "application/json",
                     "Ugate-Token": token, "access-key": _ACCESS_KEY}, method="POST")
        with r.urlopen(req, timeout=10):
            print(f"满意度已记录：{value}")
    except Exception as e:
        print(f"满意度回填失败（不影响主流程）: {e}", file=sys.stderr)

if __name__ == "__main__":
    main()
