# Changelog — design-workflow-orchestrator

## [1.0.0] — 2026-05-12
### Added
- 初始版本发布
- 补全闭环合规项（version、满意度采集章节、scripts 目录）

### TODO
- 替换 `scripts/main.py` 和 `scripts/update_satisfaction.py` 中的 `TODO_YOUR_DIST_ID` / `TODO_YOUR_VIEW_ID`
