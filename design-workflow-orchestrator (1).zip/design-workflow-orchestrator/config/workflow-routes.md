# Workflow Routes Configuration

场景到 Skill 的路由配置表。编排器动态读取此文件进行路由匹配，**扩展新Skill只需追加行，不改编排逻辑**。

---

## 路由配置表

| sceneId | phase | skillName | triggerCondition | outputType | chainTarget | notes |
|---------|-------|-----------|-----------------|------------|-------------|-------|
| SCENE_GUIDE | entry | [ask_user_question] | 用户表达"做demo/原型/产品设计"意图，无具体资源标识 | user-choice | 根据选择路由 | 展示3选项引导卡片 |
| SCENE_FIGMA | 0 | figma-make-kit | 检测到 Figma URL 或用户明确上传Figma文件 | design-token | [ask_user_question] | 完成后询问后续 |
| SCENE_PRD | 1 | prd-prompt-optimizer | 检测到文档附件/Ku链接/大段需求文字(>300字且含功能描述)/提及PRD | structured-prompt | design-demo-engineer | 无需再问，自动流转 |
| SCENE_FUZZY | 1 | requirement-intake | 仅短文字描述(<200字)，无附件，无URL，prompt不明确(缺失≥3项) | clarified-requirement | design-demo-engineer | prompt明确时跳过，直接进Phase 2 |
| SCENE_DEMO | 2 | design-demo-engineer | Phase 1 产出就绪（structured-prompt / clarified-requirement 任一） | web-demo | — | 终止节点 |
| SCENE_UNKNOWN | — | [fallback] | 置信度<0.60，所有场景均未命中 | — | — | 展示兜底4选项卡片 |

---

## 场景状态流转图

```
SCENE_GUIDE
    ├── has_figma  → SCENE_FIGMA → [询问] → SCENE_PRD 或 SCENE_FUZZY → SCENE_DEMO
    ├── has_prd    → SCENE_PRD → SCENE_DEMO
    └── has_idea   → SCENE_FUZZY → SCENE_DEMO

SCENE_FIGMA（直接入口）
    → [询问] → SCENE_PRD 或 SCENE_FUZZY 或 结束

SCENE_PRD（直接入口）
    → SCENE_DEMO

SCENE_FUZZY（直接入口）
    → SCENE_DEMO（prompt明确时跳过requirement-intake直接进入）
```

---

## 入参映射规则

### SCENE_FIGMA → figma-make-kit

```yaml
input_mapping:
  - from: figmaUrl
    to: figma_file_url           # Figma文件URL（必填）
  - from: userText
    to: extraction_focus         # 用户指定的提取重点（可选）
```

### SCENE_PRD → prd-prompt-optimizer

```yaml
input_mapping:
  - from: prdContent
    to: prd_input                # PRD文本/链接（必填）
  - from: sessionContext.designTokenPath
    to: design_context           # 设计Token路径（可选，Phase 0产出）
  - from: userText
    to: additional_context       # 用户附加说明
```

### SCENE_FUZZY → requirement-intake

```yaml
input_mapping:
  - from: userText
    to: user_requirement_description   # 用户原始需求文字
  - from: sessionContext.designTokenPath
    to: design_token_context           # 设计Token（可选，有则展示视觉风格供参考）
```

### SCENE_DEMO → design-demo-engineer

```yaml
input_mapping:
  - from: sessionContext.structuredRequirement
    to: design_prompt                  # Phase 1 产出的结构化Prompt/需求
  - from: sessionContext.designTokenPath
    to: design_token_path              # Phase 0 产出的Token（可选）
  - from: userText
    to: additional_requirements        # 用户追加说明
```

---

## 扩展示例：新增 ux-analyzer Skill

```markdown
| SCENE_UX | 1 | ux-analyzer | 检测到用户研究报告/访谈记录/用研报告关键词 | structured-prompt | design-demo-engineer | 用研转设计洞察 |
```

同时在 `references/scene-detection.md` 的优先级表中插入对应行（优先级介于SCENE_PRD和SCENE_FUZZY之间）。
