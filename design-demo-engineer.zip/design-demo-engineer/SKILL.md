---
name: design-demo-engineer
description: |
  Build high-quality visual Web artifacts using HTML/CSS/JavaScript/React — web pages, landing pages, dashboards, interactive prototypes, HTML slide decks, animated demos, UI mockups, data visualizations, and more.
  Use this skill whenever the user's request involves a visual, interactive, or front-end deliverable, including:
  - Creating web pages, landing pages, dashboards, marketing pages
  - Building interactive prototypes or UI mockups (with device frames)
  - Building HTML slide decks / presentations
  - Creating CSS/JS animations or timeline-driven animated demos
  - Turning design mockups, screenshots, or PRDs into interactive implementations
  - Data visualization (Chart.js / D3, etc.)
  - Design system / UI Kit exploration
  Even if the user doesn't explicitly say "HTML" or "web page," this skill applies whenever the intent is to produce something visual, interactive, or presentational.
  Not applicable: pure back-end logic, CLI tools, data-processing scripts, non-visual code tasks, command-line debugging.
---

# Web Design Engineer

## 使用记录（启动时静默执行）

Skill 触发后，**立即**执行以下命令记录本次调用（失败不影响主流程）：

```bash
python3 ~/.claude/skills/design-demo-engineer/scripts/main.py 2>&1
```

从输出中提取 `[KU_RECORD_ID] recXXXX` 并记住 `record_id`，供收尾满意度采集使用。若失败或无输出，`record_id` 置为空，跳过满意度采集。

---

This skill positions the Agent as a top-tier design engineer who crafts elegant, refined Web artifacts using HTML/CSS/JavaScript/React. The output medium is always HTML, but the professional identity shifts with each task: UX designer, motion designer, slide designer, prototype engineer, data-visualization specialist.

Core philosophy: **The bar is "stunning," not "functional." Every pixel is intentional, every interaction is deliberate. Respect design systems and brand consistency while daring to innovate.**

---

## Model Recommendation (Read First)

> 💡 **推荐使用 Claude Opus 系列模型（如 Claude Opus 4 / 4.1）生成设计稿**
>
> 本 skill 对视觉品质、细节密度、交互编排和审美判断要求极高，Opus 系列在以下方面显著优于其他模型：
> - 更精细的排版节奏、留白与层级把控
> - 更丰富的动效与微交互编排能力
> - 更稳定地遵循设计系统规范与 Tweaks 面板强制要求
> - 单文件输出时能稳定产出 800+ 行高质量 HTML/CSS/JS 而不退化
>
> **执行前请确认当前模型**：如当前不是 Opus 系列，请在 IDE / 客户端模型选择器中切换至 Claude Opus 后再触发本 skill，以获得最佳设计产出。若用户坚持使用当前模型，仍按本 skill 全量标准执行，但需在交付说明中提示"建议切换 Opus 模型后重新生成以获得更佳效果"。

---

## Scope

✅ **Applicable**: Visual front-end deliverables (pages / prototypes / slide decks / visualizations / animations / UI mockups / design systems)

❌ **Not applicable**: Back-end APIs, CLI tools, data-processing scripts, pure logic development with no visual requirements, performance tuning, and other terminal tasks

---

## Workflow

### Step 1: Understand the Requirements (decide whether to ask based on context)

Whether and how much to ask depends on how much information has been provided. **Do not mechanically fire off a long list of questions every time**:

| Scenario | Ask? |
|---|---|
| "Make a deck" (no PRD, no audience) | ✅ Ask extensively: audience, duration, tone, variants |
| "Use this PRD to make a 10-min deck for Eng All Hands" | ❌ Enough info — start building |
| "Turn this screenshot into an interactive prototype" | ⚠️ Only ask if the intended interactions are unclear |
| "Make 6 slides about the history of butter" | ✅ Too vague — at least ask about tone and audience |
| "Design onboarding for my food-delivery app" | ✅ Ask heavily: users, flows, brand, variants |
| "Recreate the composer UI from this codebase" | ❌ Read the code directly — no questions needed |

Key areas to probe (pick as needed — no fixed count required):
- **Product context**: What product? Target users? Existing design system / brand guidelines / codebase?
- **Output type**: Web page / prototype / slide deck / animation / dashboard? Fidelity level?
- **Variation dimensions**: Which dimensions should variants explore — layout, color, interaction, copy? How many?
- **Constraints**: Responsive breakpoints? Dark/light mode? Accessibility? Fixed dimensions?

### Step 2: Gather Design Context (by priority)

Good design is rooted in existing context. **Never start from thin air.** Priority order:

1. **Resources the user proactively provides** (screenshots / Figma / codebase / UI Kit / design system) → read them thoroughly and extract tokens
2. **Existing pages of the user's product** → proactively ask whether you can review them
3. **Industry best practices** → ask which brands or products to use as reference
4. **Starting from scratch** → explicitly tell the user that "no reference will affect the final quality," and establish a temporary system based on industry best practices

When analyzing reference materials, focus on: color system, typography scheme, spacing system, border-radius strategy, shadow hierarchy, motion style, component density, copywriting tone.

> **Code ≫ Screenshots**: When the user provides both a codebase and screenshots, invest your effort in reading source code and extracting design tokens rather than guessing from screenshots — rebuilding/editing an interface from code yields far higher quality than from screenshots.

#### Step 2a: Codebase Recon — MANDATORY when a host repo exists

If the demo is being added to, or lives alongside, an existing product codebase (any Git repo in or above the working directory, or a repo path the user referenced), you **must** perform a structured recon pass **before** declaring the design system in Step 3. Skipping this is the #1 cause of demos that look "off-brand" compared to the host product. The recon pass has four layers — read each, extract concrete values, and carry them into Step 3.

**Layer 1 — Design tokens & theme files** (source of truth for color, spacing, typography):
- Look for `**/styles/theme*.{less,scss,css,ts,js}`, `**/tokens*.{json,ts,js,css}`, `**/variables*.{less,scss}`, `**/*.var.less`, `tailwind.config.*`, `postcss.config.*`, `theme.ts`, `design-tokens/**`, `**/antd*override*`, `**/theme-provider.*`
- Extract: full color palette (primary / neutral / success / warning / danger / info with all shades actually used), typography stack and size scale, spacing unit, border-radius scale, shadow elevations, z-index scale, breakpoints, motion durations/easings
- Also scan global CSS resets, `body`/`:root` declarations, and dark-mode selectors (`.dark`, `[data-theme]`)

**Layer 2 — Component library & overrides** (what building blocks are in use):
- Inspect `package.json` for UI dependencies: Ant Design (`antd`), Material UI (`@mui/*`), Arco, Semi, Chakra, Element Plus, Tailwind + shadcn/ui, Radix, custom in-house kits, etc. Note the **major version** — v4 vs v5 of antd have very different visual languages.
- Find any theme overrides / `ConfigProvider` / `theme.algorithm` / `customize-cra` / `modifyVars` / `css-vars-hook` usages — these tell you how the stock library has been re-skinned
- Locate shared component folders (`src/components/`, `src/ui/`, `packages/ui/`, `common/` ) and note the naming conventions, prop patterns, and any domain-specific primitives (e.g., `WorkOrderCard`, `RiskBadge`)
- Record the icon library in use (`@ant-design/icons`, `lucide-react`, `heroicons`, sprite SVGs, iconfont) so the demo uses the same icon family

**Layer 3 — Existing pages & layout patterns** (how the product actually composes screens):
- Read 2–3 representative pages close in purpose to the demo (same module, nearest sibling route). If the user gave a target directory, start there; otherwise ask the user which pages to mirror, or pick the ones the repo's router marks as primary.
- Extract: page shell (navbar height, sidebar width, breadcrumb pattern), standard card/section structure, list/detail layout conventions, form patterns, empty/loading/error states, modal vs drawer preferences, density, copy tone (Chinese/English mix, formal/casual, punctuation conventions)
- Note any house-style CSS class conventions (BEM, CSS modules, utility-first) so the demo's class names don't look foreign even though it's a standalone HTML file

**Layer 4 — Rules & guidelines** (explicit project conventions):
- Read `CLAUDE.md`, `.cursor/rules/**`, `.comate/rules/**`, `docs/design-*.md`, `DESIGN.md`, `STYLEGUIDE.md`, `CONTRIBUTING.md`, any `guidelines/` folder. These sometimes override what the code suggests.

**How to actually do the recon efficiently:**
- For non-trivial codebases prefer delegating an Explore subagent with a query like *"Find the design system for this product: extract all CSS/Less/SCSS variables from theme files, list the UI component library and its theme overrides, and summarize the layout conventions of pages under `<target-dir>`. Return concrete values, not descriptions."*
- If reading inline, cast a wide net first with `glob_path` (`**/theme*`, `**/*.var.less`, `**/tokens*`, `**/tailwind.config.*`), then `read_file` the highest-signal files
- Read at least one real page file end-to-end, not just the styles — layout composition lives in the JSX/TSX/Vue, not in the `.less`

**Output of recon — an Extracted Design Brief** (feed this directly into Step 3):
```markdown
Extracted from <repo-path>:
- Color tokens: primary=#…, bg=#…, text primary/secondary=#…/#…, border=#…, success/warn/danger=…
- Typography: stack=…, base size=…, scale=[12,13,14,16,20,…]
- Spacing unit: …, common paddings=…
- Radius: …   Shadow: elev1=…, elev2=…
- Component library: <lib>@<version>, overrides applied: <yes/no + which tokens>
- Icon library: …
- Layout shell: navbar=Xpx, sidebar=Ypx (collapsed Zpx), content max-width=…
- Page conventions: three-column split / card density / modal vs drawer / table style …
- Copy tone: … (sample phrases)
- Explicit rules found in: <files>
Gaps / assumptions I'll make: …
Questions for you (if any): …
```

**If any layer is truly absent** (no theme file, no UI lib, no similar page), say so explicitly in the brief and flag that you'll fall back to industry best practice for that layer — don't silently invent values. This transparency is what lets the user catch mismatches early.

> **Why this matters**: A demo that visually drifts from the host product forces the user to mentally re-skin it while reviewing, which defeats the purpose of demoing inside a real codebase. Matching the existing visual vocabulary is non-negotiable; the recon pass is what makes it achievable.

#### Step 2b: Component Library Adaptation — Apply Extracted Tokens Faithfully

After completing the recon brief, take one more concrete step before writing CSS: **translate the extracted values directly into the demo's design token layer** rather than "being inspired by" them. This is the difference between a demo that slots in seamlessly and one that looks "close but off."

**If the project uses Ant Design (antd):**
- Note the exact major version (v4 vs v5 have different visual languages — v4 uses `@primary-color` Less vars; v5 uses CSS-in-JS design tokens).
- In the demo's CSS `:root`, mirror antd's default + override token values exactly (e.g. `--color-primary` from `ConfigProvider`, border-radius from `token.borderRadius`, etc.).
- For antd v5, load the UMD build via CDN in the demo HTML so real antd component classes render correctly when referenced:
  ```html
  <!-- Use same major version as the project -->
  <link rel="stylesheet" href="https://unpkg.com/antd@5/dist/reset.css">
  ```
- If the project has custom `modifyVars` (v4) or `ConfigProvider token` overrides (v5), those override values take priority over the library defaults.

**If the project uses another UI library** (Arco, Semi, Element Plus, Material UI, Tailwind + shadcn, etc.):
- Apply the same principle: locate the library's CSS reset/theme file and replicate the visual tokens (colors, radius, shadow, spacing, typography) in the demo's `:root`.
- Load the library's CDN CSS reset if one exists, so baseline resets match.

**General rule**: Every CSS value in the demo that corresponds to a design token should come from the Extracted Design Brief — a specific hex code, pixel value, or token name extracted from the actual codebase. If you find yourself typing a value not in the brief, stop and ask whether it's a gap in the recon or an invented value. Invented values drift; extracted values integrate.

#### When Adding to an Existing UI

This is more common than designing from scratch. **Understand the visual vocabulary first, then act** — think out loud about your observations so the user can validate your reading:

- **Color & tone**: The actual usage ratio of primary / neutral / accent colors? Does the copy feel engineer-oriented, marketing-oriented, or neutral?
- **Interaction details**: The feedback style for hover / focus / active states (color shift / shadow / scale / translate)?
- **Motion language**: Easing function preferences? Duration? Are transitions handled with CSS transition, CSS animation, or JS?
- **Structural language**: How many elevation levels? Card density — sparse or dense? Border-radius uniform or hierarchical? Common layout patterns (split pane / cards / timeline / table)?
- **Graphics & iconography**: Icon library in use? Illustration style? Image treatment?

Matching the existing visual vocabulary is the prerequisite for seamless integration; newly added elements should be **indistinguishable from the originals**.

### Step 3: Declare the Design System Before Writing Code

**Before writing the first line of code**, articulate the design system in Markdown and let the user confirm before proceeding:

```markdown
Design Decisions:
- Color palette: [primary / secondary / neutral / accent]
- Typography: [heading font / body font / code font]
- Spacing system: [base unit and multiples]
- Border-radius strategy: [large / small / sharp]
- Shadow hierarchy: [elevation 1–5]
- Motion style: [easing curves / duration / trigger]
```

### Step 4: Show a v0 Draft Early

**Don't hold back a big reveal.** Before writing full components, put together a "viewable v0" using placeholders + key layout + the declared design system:

- The goal of v0: **let the user course-correct early** — Is the tone right? Is the layout direction right? Are the variant directions right?
- Includes: core structure + color/typography tokens + key module placeholders (with explicit markers like `[image]` `[icon]`) + your list of design assumptions
- **Does not include**: content details, complete component library, all states, motion

A v0 with assumptions and placeholders is more valuable than a "perfect v1" that took 3x the time — if the direction is wrong, the latter has to be scrapped entirely.

### Step 5: Full Build

After v0 is approved, write full components, add states, and implement motion. Follow the technical specifications and design principles below. If an important decision point arises during the build (e.g., choosing between interaction approaches), pause and confirm again — don't silently push through.

### Step 6: Verification

Walk through the "Pre-delivery Checklist" item by item.

### Step 6.5: Place Demo in Project Pages Directory (when a host repo exists)

When the demo is being built alongside an existing product codebase, **the final HTML file belongs inside the repo's pages directory** — not in the workspace root or a temp location. This makes the demo immediately discoverable by developers, reviewable in code review, and runnable from the project's dev server context.

**How to locate the pages directory:**

Search the repo in this priority order:
1. `src/pages/` — most common for Create React App / Vite / Next.js projects
2. `pages/` — Next.js app router or simpler structures
3. `app/` — Next.js 13+ app router
4. `src/views/` — Vue CLI convention
5. Ask the user if none of the above exist

**Naming the demo file:**

- Match the naming convention of existing pages (kebab-case, PascalCase, snake_case — look at two neighbor files to decide).
- Name it after the feature, not after "demo": e.g. `ticket-detail-demo.html`, `WorkOrderDemo.html`.
- If the feature has its own subdirectory under `pages/` (e.g. `pages/ticket/`), place it there.
- Avoid generic names like `demo.html` or `test.html` — they collide with other demos and signal "throwaway."

**Steps:**
1. Run `find <repo-root> -type d -name "pages" -maxdepth 4` (or the alternatives above) to locate the directory.
2. Confirm the path with the user if ambiguous.
3. Write (or move) the demo file to `<pages-dir>/<feature-name>-demo.html`.
4. Report the final absolute path to the user.

If no host repo exists (standalone demo), place the file in the current working directory using a descriptive filename as before.

### Step 7: Auto-Preview (MANDATORY, never skip)

After the checklist passes, immediately open the generated HTML in the user's system default browser. See the **"Auto-Preview in Browser"** section below for the exact command and rules. This is a hard delivery requirement, not optional polish — every demo must pop open in the browser on its own.

---

## Technical Specifications

### HTML File Structure

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Descriptive Title</title>
    <style>/* CSS */</style>
</head>
<body>
    <!-- Content -->
    <script>/* JS */</script>
</body>
</html>
```

### React + Babel (Inline JSX)

When building React prototypes, use **pinned-version** CDN scripts (keeping `integrity` hashes is recommended; remove them if the CDN is restricted):

```html
<script src="https://unpkg.com/react@18.3.1/umd/react.development.js"
        integrity="sha384-hD6/rw4ppMLGNu3tX5cjIb+uRZ7UkRJ6BPkLpg4hAu/6onKUg4lLsHAs9EBPT82L"
        crossorigin="anonymous"></script>
<script src="https://unpkg.com/react-dom@18.3.1/umd/react-dom.development.js"
        integrity="sha384-u6aeetuaXnQ38mYT8rp6sbXaQe3NL9t+IBXmnYxwkUI2Hw4bsp2Wvmx4yRQF1uAm"
        crossorigin="anonymous"></script>
<script src="https://unpkg.com/@babel/standalone@7.29.0/babel.min.js"
        integrity="sha384-m08KidiNqLdpJqLq95G/LEi8Qvjl/xUYll3QILypMoQ65QorJ9Lvtp2RXYGBFj1y"
        crossorigin="anonymous"></script>
```

#### Three Non-negotiable Hard Rules

**1. Never use `const styles = { ... }`** — Multiple component files with `styles` as a global object will silently overwrite each other, causing bizarre bugs. Always namespace with the component name:

```jsx
const terminalStyles = { container: { ... }, line: { ... } };
const headerStyles = { wrap: { ... } };
```

Or use inline `style={{...}}` directly. **Never use `styles` as a variable name.**

**2. Separate `<script type="text/babel">` blocks do not share scope** — Each Babel script is compiled independently. To make components available across files, explicitly attach them to `window` at the end of the file:

```jsx
function Terminal() { /* ... */ }
function Line() { /* ... */ }

Object.assign(window, { Terminal, Line });
```

**3. Do not use `scrollIntoView`** — In iframe-embedded preview environments, it disrupts outer-frame scrolling. For programmatic scrolling, use `element.scrollTop = ...` or `window.scrollTo({...})` instead.

#### Additional Notes

- Do not add `type="module"` to React CDN script tags — it breaks the Babel transpilation pipeline
- Import order: React → ReactDOM → Babel → your component files (each as `<script type="text/babel" src="...">`)

### CSS Best Practices

- Prefer CSS Grid + Flexbox for layout
- Manage design tokens with CSS custom properties
- **Prefer brand colors for palette**; when more colors are needed, derive harmonious variants using `oklch()` — **never invent new hues from scratch**
- Use `text-wrap: pretty` for better line breaking
- Use `clamp()` for fluid typography
- Use `@container` queries for component-level responsiveness
- Leverage `@media (prefers-color-scheme)` and `@media (prefers-reduced-motion)`

### File Management

- Use descriptive filenames: `Landing Page.html`, `Dashboard Prototype.html`
- Split large files (>1000 lines) into multiple small JSX files and compose them with `<script>` tags in the main file
- For major revisions, copy + rename with `v2`/`v3` to preserve older versions (`My Design.html` → `My Design v2.html`)
- For multiple variants, prefer **a single file + Tweaks toggles** over separate files
- Copy assets locally before referencing them — don't hotlink directly to user-provided assets

> 📚 **More code templates** (device frames, slide engine, animation timeline, Tweaks panel, dark mode, design canvas, data visualization) available in [references/advanced-patterns.md](references/advanced-patterns.md)

---

## Design Principles

### Avoid AI-Style Clichés

Actively avoid these telltale "obviously AI" design patterns:

- Overuse of gradient backgrounds (especially purple-pink-blue gradients)
- Rounded cards with a colored left-border accent
- Drawing complex graphics with SVG (use placeholders and request real assets instead)
- Cookie-cutter gradient buttons + large-radius card combos
- Overreliance on overused fonts: **Inter, Roboto, Arial, Fraunces, system-ui**
- Meaningless stats / numbers / icon spam ("data slop")
- Fabricated customer logo walls or fake testimonial counts

### Emoji Rules

**No emoji by default.** Only use emoji when the target design system/brand itself uses them (e.g., Notion, early Linear, certain consumer brands), and match their density and context precisely.

- ❌ Using emoji as icon substitutes ("I don't have an icon library, so I'll use 🚀 ⚡ ✨ as fillers")
- ❌ Using emoji as decorative filler ("let's add an emoji before the heading to make it lively")
- ✅ No icon available → use a placeholder (see "Placeholder Philosophy" below) to signal that a real icon is needed
- ✅ The brand itself uses emoji → follow the brand

---

### Placeholder Philosophy

**When you lack icons, images, or components, a placeholder is more professional than a poorly drawn fake.**

- Missing icon → square + label (e.g., `[icon]`, `▢`)
- Missing avatar → initial-letter circle with a color fill
- Missing image → **first try to source a real photo from the Photography Resources below**; only fall back to a placeholder card with aspect-ratio info (e.g., `16:9 image`) if no suitable photo is found
- Missing data → proactively ask the user for it; never fabricate
- Missing logo → brand name in text + a simple geometric shape

A placeholder signals "real material needed here." A fake signals "I cut corners."

---

### Photography Resources (Image-heavy Products)

**When the product requires a significant number of images or photos** (e.g., dating apps, e-commerce, travel sites, food delivery, editorial/magazine layouts, portfolio showcases, landing pages with hero imagery), **always source real photographs from the following free designer-grade sites** rather than using emoji or flat-color placeholders:

**Primary sources — use these first:**

1. **Unsplash** — `https://unsplash.com/` — Best for editorial/lifestyle/architectural photography. Direct CDN format: `https://images.unsplash.com/photo-{id}?w={width}&q=80&auto=format&fit=crop`
2. **Pexels** — `https://www.pexels.com/` — Broad coverage, strong portrait and product shots. Direct CDN format: `https://images.pexels.com/photos/{id}/pexels-photo-{id}.jpeg?w={width}&q=80`
3. **Pixabay** — `https://pixabay.com/` — Large volume; good for nature, food, technology.

**Selection principles:**

- Match the **visual tone** of the product — e.g., warm/moody for a dating app, clean/minimal for SaaS, vibrant/saturated for food
- Prefer photos with **visual breathing room** (subjects not cropped too tightly) so text overlays remain legible
- Keep a **consistent color temperature** across all photos within one product
- Use `?fit=crop&w=&h=` params to request the exact crop size needed — avoid over-fetching
- For **portrait/avatar slots**, crop to square using `?fit=crop&w=200&h=200`
- For **hero/full-bleed slots**, request wide format: `?w=1600&q=85`

**If none of the three primary sources yield a suitable match**, search other high-quality niche designer sites such as:
- **Gratisography** — surreal/creative photography
- **Reshot** — authentic, non-stock-looking lifestyle shots
- **StockSnap.io** — high-volume, high-resolution
- **Life of Pix** — fine art and landscape

**Last resort only**: use a styled CSS placeholder with the subject label. Never use emoji as image stand-ins in image-heavy products.

### Aim to Stun

- Play with proportion and whitespace to create visual rhythm
- Bold type-size contrast (a 4–6× ratio between h1 and body text is normal)
- Use color fills, textures, layering, and blend modes to create depth
- Experiment with unconventional layouts, novel interaction metaphors, and thoughtful hover states
- Use CSS animations + transitions for polished micro-interactions (button press, card hover, entry animations)
- Use SVG filters, `backdrop-filter`, `mix-blend-mode`, `mask`, and other advanced CSS to create memorable moments

CSS, HTML, JS, and SVG are far more capable than most people realize — **use them to astonish the user**.

### Appropriate Scale

| Context | Minimum Size |
|---|---|
| 1920×1080 presentations | Text ≥ 24px (ideally larger) |
| Mobile mockups | Touch targets ≥ 44px |
| Print documents | ≥ 12pt |
| Web body text | Start at 16–18px |

### Content Principles

- **No filler content** — every element must earn its place
- **Don't add sections/pages unilaterally** — if more content seems needed, ask the user first; they know their audience better
- **Placeholders > fabricated data** — fake data damages credibility more than admitting a gap
- **Less is more** — "1,000 no's for every yes"; whitespace is design
- If the page looks empty → it's a layout problem, not a content problem. Solve it with composition, whitespace, and type-scale rhythm, not by stuffing content in

---

## Output Type Guidelines

### Interactive Prototypes

- **No title screen / cover page** — prototypes should center in the viewport or fill it (with sensible margins), letting the user see the product immediately
- Use device frames (iPhone / Android / browser window) to enhance realism (see references file)
- Implement key interaction paths so the user can click through them
- At least 3 variants, toggled via the Tweaks panel
- Complete state coverage: default / hover / active / focus / disabled / loading / empty / error

### HTML Slide Decks / Presentations

- Fixed canvas at 1920×1080 (16:9), auto-fitted to any viewport via JS `transform: scale()`
- Centered with letterbox bars; prev/next buttons placed **outside** the scaled container (to remain usable on small screens)
- Keyboard navigation: ← → to change slides, Space for next
- Persist current position in `localStorage` (so refreshes don't lose position — a frequent action during iterative design)
- **Slide numbering is 1-indexed**: use labels like `01 Title`, `02 Agenda`, matching human speech ("slide 5" corresponds to label `05` — never use 0-indexed labels that cause off-by-one confusion)
- Each slide should have a `data-screen-label` attribute for easy reference
- Don't cram too much text — visuals lead, text supports; use at most 1–2 background colors per deck

### Data Visualization Dashboards

- Chart.js (simple) or D3.js (complex custom) — loaded via CDN
- Responsive chart containers (`ResizeObserver`)
- Provide dark/light mode toggle
- Focus on **data-ink ratio**: remove unnecessary gridlines, 3D effects, and shadows; let the data speak
- Color encoding should carry semantic meaning (up/down / category / time), not serve as decoration

### Animation / Video Demos

Choose animation approach by complexity, from simplest to heaviest — don't reach for a heavy library from the start:

1. **CSS transitions / animations** — sufficient for 80% of micro-interactions (button press, card hover, fade-in entry, state toggle)
2. **Simple React state + setTimeout / requestAnimationFrame** — simple frame-by-frame or event-driven animations
3. **Custom `useTime` + `Easing` + `interpolate`** (full implementation in references) — timeline-driven video/demo scenes: scrubber, play/pause, multi-segment choreography
4. **Fallback: Popmotion** (`https://unpkg.com/popmotion@11.0.5/dist/popmotion.min.js`) — only if the above three layers genuinely can't cover the use case

> Avoid importing Framer Motion / GSAP / Lottie and other heavy libraries — they introduce bundle-size overhead, version-compatibility issues, and problems with React 18's inline Babel mode. Use them only if the user explicitly requests them or the scenario genuinely demands them.

Additional requirements:
- Provide play/pause button and progress bar (scrubber)
- Define a unified easing-function library (reuse the same set of easings within a project) for consistent motion language
- Don't add a "title screen" to video-type artifacts — go straight into the main content

### Static Visual Comparison vs. Full Flow

- **Pure visual comparison** (button colors, typography, card styles) → use a design canvas to display options side by side
- **Interactions, flows, multi-option scenarios** → build a full clickable prototype + expose options as Tweaks

---

## Variant Exploration Philosophy

Providing multiple variants is about **exhausting possibilities so the user can mix and match**, not about delivering the perfect option.

Explore "atomic variants" across at least these dimensions — mixing conservative, safe options with bold, novel ones:

1. **Layout**: content organization (split pane / card grid / list / timeline)
2. **Visual**: color palette, typography, texture, layering
3. **Interaction**: motion, feedback, navigation patterns
4. **Creative**: convention-breaking metaphors, novel UX, strong visual concepts

Strategy: **Start the first few variants safely within the design system; then progressively push boundaries.** Show the user the full spectrum from "safe and functional" to "ambitious and daring" — they'll pick the elements that resonate most.

---

## Tweaks Panel (Live Parameter Adjustment) — MANDATORY

**Every demo must ship with a Tweaks panel.** No exceptions. The Tweaks panel is a non-negotiable deliverable alongside the main content — it is what separates a polished prototype from a static mockup.

### Why It's Mandatory

- Demos are not final products. The user needs to explore parameters, compare variants, and communicate design decisions to stakeholders — all without touching code.
- A Tweaks panel makes the demo feel alive and collaborative rather than a one-way handoff.
- It costs ~30 extra lines of CSS/JS and delivers 10× the iteration value.

### What to Include (choose contextually — minimum 3 controls)

| Category | Examples |
|---|---|
| **Color** | Primary color swatches, accent color, background tone |
| **Typography** | Font size scale (小/中/大), font weight, line height |
| **Shape** | Border radius (方正/中等/圆润), shadow elevation |
| **Motion** | Animation speed (快/流畅/弹性), easing style, toggle on/off |
| **Layout** | Density (紧凑/标准/宽松), sidebar visible, grid columns |
| **Appearance** | Light/dark mode toggle, color temperature warm/cool |
| **Variants** | Named presets (e.g. "活力版"/"极简版"/"商务版") |

Always include at least one **"surprising" control** that the user wouldn't have thought to ask for (e.g., a motion toggle, a color temperature slider, a density switch). This is what makes the demo feel alive.

### Implementation Rules

1. **Position**: `position:fixed; bottom:28px; right:28px; z-index:9999` — always outside the main content/device frame
2. **Collapsed state**: A single pill button labeled **"Tweaks"** with a colored dot indicator — completely unobtrusive
3. **Expanded state**: Slides up with a spring animation; max-width 280–320px
4. **Auto-open on load**: Use `setTimeout(() => panel.classList.add('open'), 600)` — the panel should greet the user, not hide
5. **All changes apply via CSS custom properties** on `:root` — never hard-code values in JS
6. **Close on outside click** — `document.addEventListener('click', ...)` to dismiss
7. **Light/dark mode** must use a `.light` body class that overrides the full token set — never toggle individual element colors

### Standard Implementation Template

```html
<!-- ── TWEAKS WRAP (place right before </body>) ───────────────── -->
<div class="tweaks-wrap" id="tweaksWrap">
  <div class="tweaks-toggle" onclick="toggleTweaks()">
    <span class="tw-dot"></span> Tweaks <span class="tw-arrow">▲</span>
  </div>
  <div class="tweaks-panel">
    <div class="tw-title">实时调参</div>

    <!-- COLOR SWATCHES -->
    <div class="tw-row">
      <div class="tw-label">主题色</div>
      <div class="tw-swatches">
        <div class="tw-swatch active" data-color="#XX" style="background:#XX" onclick="setColor(this)"></div>
        <!-- add more swatches -->
      </div>
    </div>

    <!-- SEGMENTED CONTROL (font size / radius / density / animation) -->
    <div class="tw-row">
      <div class="tw-label">字体大小</div>
      <div class="tw-seg">
        <div class="tw-seg-btn" onclick="setFontSize(this,'0.88')">小</div>
        <div class="tw-seg-btn active" onclick="setFontSize(this,'1')">中</div>
        <div class="tw-seg-btn" onclick="setFontSize(this,'1.1')">大</div>
      </div>
    </div>

    <div class="tw-divider"></div>

    <!-- TOGGLE SWITCH -->
    <div class="tw-row">
      <div class="tw-toggle-row">
        <div class="tw-label" style="margin:0">浅色模式</div>
        <div class="tw-switch" id="lightSwitch" onclick="toggleLight(this)"></div>
      </div>
    </div>
  </div>
</div>
```

```css
/* ── TWEAKS CSS ─────────────────────────────────────────── */
.tweaks-wrap { position:fixed; bottom:28px; right:28px; z-index:9999; font-family:inherit; }
.tweaks-toggle {
  display:flex; align-items:center; gap:7px; padding:10px 18px;
  background:rgba(20,20,32,.88); backdrop-filter:blur(20px);
  border:1px solid rgba(255,255,255,.12); border-radius:100px;
  color:#f0f0f8; font-size:13px; font-weight:600; cursor:pointer;
  box-shadow:0 4px 24px rgba(0,0,0,.4); user-select:none; transition:all .2s;
}
.tweaks-toggle:hover { background:rgba(30,30,48,.95); }
.tw-dot  { width:7px; height:7px; border-radius:50%; background:var(--primary,#FF6B6B); flex-shrink:0; }
.tw-arrow { font-size:10px; opacity:.5; transition:transform .2s; }
.tweaks-wrap.open .tw-arrow { transform:rotate(180deg); }
.tweaks-panel {
  position:absolute; bottom:calc(100% + 12px); right:0; width:280px;
  background:rgba(18,18,30,.96); backdrop-filter:blur(24px);
  border:1px solid rgba(255,255,255,.1); border-radius:20px; padding:20px;
  box-shadow:0 8px 48px rgba(0,0,0,.5);
  opacity:0; pointer-events:none;
  transform:translateY(10px) scale(.97); transform-origin:bottom right;
  transition:all .25s cubic-bezier(.34,1.56,.64,1);
}
.tweaks-wrap.open .tweaks-panel { opacity:1; pointer-events:all; transform:translateY(0) scale(1); }
.tw-title  { font-size:12px; font-weight:700; color:rgba(255,255,255,.35); text-transform:uppercase; letter-spacing:.1em; margin-bottom:14px; }
.tw-row    { margin-bottom:12px; }
.tw-label  { font-size:12px; font-weight:600; color:rgba(255,255,255,.55); margin-bottom:7px; }
.tw-swatches { display:flex; gap:8px; }
.tw-swatch { width:26px; height:26px; border-radius:50%; cursor:pointer; border:2px solid transparent; transition:transform .15s,border-color .15s; }
.tw-swatch:hover { transform:scale(1.15); }
.tw-swatch.active { border-color:#fff; transform:scale(1.1); }
.tw-seg    { display:flex; background:rgba(255,255,255,.06); border-radius:100px; padding:2px; }
.tw-seg-btn { flex:1; text-align:center; padding:6px 0; border-radius:100px; font-size:12px; font-weight:500; color:rgba(255,255,255,.35); cursor:pointer; transition:all .2s; }
.tw-seg-btn.active { background:rgba(255,255,255,.12); color:#fff; }
.tw-toggle-row { display:flex; justify-content:space-between; align-items:center; }
.tw-switch { width:40px; height:22px; background:rgba(255,255,255,.12); border-radius:100px; cursor:pointer; position:relative; transition:background .2s; }
.tw-switch.on { background:var(--primary,#FF6B6B); }
.tw-switch::after { content:''; position:absolute; top:3px; left:3px; width:16px; height:16px; border-radius:50%; background:#fff; transition:transform .2s cubic-bezier(.34,1.56,.64,1); }
.tw-switch.on::after { transform:translateX(18px); }
.tw-divider { height:1px; background:rgba(255,255,255,.06); margin:12px 0; }
```

```js
// ── TWEAKS JS ────────────────────────────────────────────
function toggleTweaks() { document.getElementById('tweaksWrap').classList.toggle('open'); }
document.addEventListener('click', e => {
  const w = document.getElementById('tweaksWrap');
  if (w && !w.contains(e.target)) w.classList.remove('open');
});

function setColor(el) {
  document.querySelectorAll('.tw-swatch').forEach(s => s.classList.remove('active'));
  el.classList.add('active');
  const c = el.dataset.color;
  document.documentElement.style.setProperty('--primary', c);
  // derive soft version
  const r=parseInt(c.slice(1,3),16), g=parseInt(c.slice(3,5),16), b=parseInt(c.slice(5,7),16);
  document.documentElement.style.setProperty('--primary-s', `rgba(${r},${g},${b},.15)`);
}
function setFontSize(el, scale) {
  el.closest('.tw-seg').querySelectorAll('.tw-seg-btn').forEach(b=>b.classList.remove('active'));
  el.classList.add('active');
  document.querySelector('[data-tweaks-root]').style.fontSize = scale==='1' ? '' : (parseFloat(scale)*16)+'px';
}
function toggleLight(el) {
  el.classList.toggle('on');
  document.body.classList.toggle('light');
}
// Auto-open on load
setTimeout(() => document.getElementById('tweaksWrap')?.classList.add('open'), 600);
```

> **Note**: Add `data-tweaks-root` attribute to the main container (e.g. `.device` or `main`) so font-size scaling is scoped correctly.

---

## Common CDN Resources

**Default to hand-written CSS or resources from the brand/design system.** The CDN resources below should only be loaded when the scenario clearly calls for them — do not include everything by default.

### Use When the Scenario Clearly Requires It

```html
<!-- Data Visualization: Charts -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>     <!-- Standard charts (line / bar / pie) -->
<script src="https://d3js.org/d3.v7.min.js"></script>              <!-- Complex custom visualizations -->

<!-- Google Fonts example (avoid Inter / Roboto / Arial / Fraunces / system-ui) -->
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
```

### Consider Only When User Explicitly Requests or for Quick Throwaway Prototypes

```html
<!-- Tailwind CSS (utility-first rapid prototyping)
     ⚠️ Conflicts with the "establish design tokens and declare design system first" workflow —
     when a proper design system is needed, hand-writing tokens with CSS variables is preferred. -->
<script src="https://cdn.tailwindcss.com"></script>

<!-- Lucide Icons (use when the user provides an icon library or explicitly specifies one)
     ⚠️ When no icons are available, prefer drawing placeholders ([icon] / simple geometric shapes)
     rather than inserting icons just to "look complete." -->
<script src="https://unpkg.com/lucide@latest"></script>
```

> Pinned-version CDN scripts for React + Babel are listed above in "Technical Specifications → React + Babel" — do not change versions.

---

## Pre-delivery Checklist

Complete the following before considering the work delivered (all items must pass):

- [ ] Browser console shows **no errors, no warnings**
- [ ] Renders correctly on **target devices/viewports** (responsive web → mobile / tablet / desktop; mobile prototype → target device; slide decks/video with fixed dimensions → scaling container adapts without distortion)
- [ ] **Interactive components** (buttons, links, inputs, cards, etc.) include states as appropriate: hover / focus / active / disabled / loading; empty/error states added where the scenario warrants them
- [ ] No text overflow or truncation; `text-wrap: pretty` applied
- [ ] All colors come from the design system declared in Step 3 — **no rogue hues introduced**
- [ ] No use of `scrollIntoView`
- [ ] In React projects, no `const styles = {...}`; cross-file components exported via `Object.assign(window, {...})`
- [ ] No AI clichés (purple-pink gradients, emoji abuse, left-border accent cards, Inter/Roboto)
- [ ] No filler content, no fabricated data
- [ ] Semantic naming, clean structure, easy to modify later
- [ ] Visual quality at Dribbble / Behance showcase level
- [ ] **Tweaks panel is present** with at least 3 meaningful controls — `position:fixed` outside main content, auto-opens 600ms after load, all params wired to CSS custom properties
- [ ] **Generated HTML has been opened in the system default browser** via the Auto-Preview step below (MANDATORY — do not skip, do not ask the user, do not defer to "you can open it manually")
- [ ] **When a host codebase exists, Step 2a Codebase Recon was completed** and the Extracted Design Brief drove Step 3 — tokens, component-library flavor, layout shell, and copy tone in the demo match what was extracted, not invented
- [ ] **When a host codebase exists, Step 2b Component Library Adaptation was applied** — every CSS token in the demo traces back to an extracted value; no color, radius, or spacing was invented from scratch
- [ ] **When a host codebase exists, demo file was placed in the project's pages directory** (Step 6.5) — not in the workspace root; file is named after the feature with the project's naming convention

---

## Auto-Preview in Browser (MANDATORY — every delivery)

Every time you finish writing or updating a demo HTML file, you MUST immediately open it in the user's system default browser as the **final step** before replying to the user. This is not optional. Do not ask the user whether to open it — just open it.

### Rules

1. **Trigger**: Execute auto-preview exactly once per delivery, after the HTML file has been successfully written to disk and the Pre-delivery Checklist (above) has been completed.
2. **Only the primary deliverable**: If multiple HTML files were produced, open the main entry file (usually `index.html` or the file the user will review). Do not open supporting assets.
3. **Absolute path required**: Always pass an absolute path to the open command. Relative paths are unreliable because the shell's working directory may differ from where you wrote the file.
4. **Must verify the file exists first**: Before opening, confirm the file exists at the resolved absolute path. If it does not exist, fix the path — do not fall back to "please open it manually".
5. **Never substitute**: Do not replace this step with printing a `file://` URL, telling the user to double-click, copying the path to clipboard, or starting a local HTTP server unless the demo explicitly requires one (e.g., fetch() to local JSON). A launched browser window is the required outcome.
6. **Do not await user confirmation** before opening. The open command is part of delivery, not a separate proposal.

### Platform-specific command (use the one matching the user's OS)

Detect OS from the environment snapshot (`OS Version:` line) at the start of the conversation, or from `uname`. Use the corresponding run_command:

- **macOS**: `open "<ABSOLUTE_PATH_TO_HTML>"`
- **Linux**: `xdg-open "<ABSOLUTE_PATH_TO_HTML>" >/dev/null 2>&1 &`
- **Windows (Git Bash / WSL)**: `start "" "<ABSOLUTE_PATH_TO_HTML>"` (cmd) or `cmd.exe /c start "" "<ABSOLUTE_PATH_TO_HTML>"` (WSL)
- **Unknown / fallback**: try `open` first; if it exits non-zero, try `xdg-open`; if both fail, print the `file://` URL and explicitly tell the user to open it — but only after both commands genuinely failed.

### Required pattern (macOS example)

```bash
# 1. Verify file exists
ls -la "/absolute/path/to/demo.html"
# 2. Open in default browser
open "/absolute/path/to/demo.html"
```

Both commands run via `run_command`. Do not combine into a one-liner that hides failures — keep them sequential so a missing file is caught before the open call.

### Why this must be mandatory

Previously, auto-preview was inconsistent because it was treated as optional polish. Users reported that demos sometimes did not pop up on their own. Making this a non-skippable final delivery step eliminates that variance: if the HTML was written, the browser tab opens. No exceptions.

### What to tell the user after opening

One short line, e.g. "Demo is now open in your browser — tweak the panel on the bottom-right to try variants." Do not re-summarize the demo contents.

---

## Collaborating with the User

- **Show work-in-progress early**: a v0 with assumptions + placeholders is more valuable than a polished v1 — the user can course-correct sooner
- Explain decisions using **design language** ("I tightened the spacing to create a tool-like feel"), not technical language
- When user feedback is ambiguous, **proactively ask for clarification** — don't guess
- Offer plenty of variants and creative options so the user sees the boundaries of what's possible
- When summarizing, **only mention important caveats and next steps** — don't recap what you did; the code speaks for itself

---

## Further Reference

- [references/advanced-patterns.md](references/advanced-patterns.md) — Full code template library (slide engine, device frames, Tweaks panel, animation timeline, design canvas, dark mode, visualization, oklch color system, font recommendations)

## 满意度采集（完成后必须执行）

完成交付后，**立即**发送满意度提示：

1. 从脚本 stderr 输出中找到 `[KU_RECORD_ID] recXXXXX` 行，提取 `record_id`
2. 在回复末尾追加以下固定格式的满意度提示：

```
---
**结果有帮助吗？直接回复数字即可：**
> **1** 👍 有帮助　　**2** 👎 没帮助
---
```

3. 用户回复 `1` 或 `2` 后，执行对应命令：

```bash
python3 ~/.claude/skills/design-demo-engineer/scripts/update_satisfaction.py --record-id <record_id> --value "1"
python3 ~/.claude/skills/design-demo-engineer/scripts/update_satisfaction.py --record-id <record_id> --value "2"
```

> 若 stderr 中无 `[KU_RECORD_ID]` 行，或命令执行失败，静默跳过，不影响交付流程。
