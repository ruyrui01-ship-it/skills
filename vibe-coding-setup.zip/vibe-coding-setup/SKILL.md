---
name: vibe-coding-setup
description: >
  Help users prepare a local dev environment to start developing, running, or modifying
  an existing code repository. Trigger whenever the user wants to "开发"/"基于这个仓库开发"/
  "把仓库拉下来跑起来"/"本地启动"/"克隆这个仓库"/"配置环境"/"搭环境"/"装依赖"/
  "start this project locally"/"clone and run this repo"/"set up dev env",
  or pastes a git/icode repo URL and implies they want to work on it.
  Supports baidu icode (icode.baidu.com) via the icode skill, plus github/gitlab/bitbucket
  via plain git clone. Auto-detects project language (node.js, python, java, go, ruby, php,
  rust) from lockfiles and manifests, installs the correct toolchain, installs dependencies,
  configures .env files, opens the project in the detected IDE, and starts the dev server.
  Consent-first flow on macOS, Windows, and Linux.
---

# Vibe Coding Setup

## 使用记录（启动时静默执行）

Skill 触发后，**立即**执行以下命令记录本次调用（失败不影响主流程）：

```bash
python3 ~/.claude/skills/vibe-coding-setup/scripts/main.py 2>&1
```

从输出中提取 `[KU_RECORD_ID] recXXXX` 并记住 `record_id`，供收尾满意度采集使用。若失败或无输出，`record_id` 置为空，跳过满意度采集。

---

## Operating Mode

Consent-first, then automated. Always follow "Startup Flow" below: do read-only detection first, summarize, and only then ask the user to approve each write action. Once approved, run the approved batch silently and report results at the end — do not ping per command inside an approved phase.

**Automation principle (within an approved step):** if you can run a command, run it. Do not ask the user to:
- leave the IDE to read external documentation
- visit a website to copy an install command
- manually type a command that you could execute yourself
- `cd` into nested folders when you can auto-locate them
- make decisions that can be inferred from project files

Use hardcoded, known-good install commands directly. If a hardcoded URL or command fails, treat it as an error and try the documented fallback — do not dump the problem back on the user.

This skill supports Node.js, Python, Java, Go, Ruby, PHP, and Rust projects. Language is auto-detected from files in the repo (see "Language Detection" below). If detection fails or the project uses an unsupported stack (Swift, C#, Flutter, etc.), tell the user plainly and stop.

Supported IDEs: **Comate** (the primary target — this skill most often runs inside Comate itself), **VS Code**, and **Cursor**. When the skill is running inside Comate, the IDE is already open — "opening the project in the IDE" means opening the project folder within the current Comate window, not launching a new IDE. Do not treat Comate as "not installed" just because a terminal `comate --version` check fails; recognize it from the runtime environment instead.

If the current environment can execute commands directly, run all approved steps in sequence and report results at the end. If direct execution is not available, batch the copy-paste commands for each phase rather than sending one command at a time.

## Startup Flow

Follow these steps in order on every invocation. Do not skip ahead.

1. **Explain read-only checks and ask permission.** Tell the user you will first run non-destructive detection (OS, IDE, existing tools, current folder contents) and wait for their approval before running anything.
2. **Run environment detection.** Read-only only — OS, host IDE (see "IDE Auto-Detection"), installed toolchains (`node -v`, `python --version`, `git --version`, etc.), and whether the current working directory already contains a recognizable project (marker files listed in "Language Detection").
3. **Summarize what was detected.** Report OS, IDE, toolchain versions, and whether a project was found (including its detected language if any). Keep the summary short and factual.
4. **Decide the workflow based on detection:**
   - **Existing repo detected in the current folder** → continue with setup for that project.
   - **No repo detected** → ask the user which path to take: clone a new repo (request URL), open an existing local folder (request path), or create a new project from scratch (request language/template).
5. **Before any write action, ask confirmation.** For every installation, dependency install, clone, file creation, or shell-config change, first explain what will be installed/created/modified and why, then wait for an explicit "go". Batch related actions into one confirmation where reasonable (e.g., "install nvm + Node 20 + run `yarn install`") rather than asking per-command.

This consent-first flow overrides any earlier "collect everything upfront then auto-execute" instruction. Automation still applies *within* an approved step — once the user says go, run the whole batch silently and report results, without pinging them per command.

## IDE Auto-Detection

Infer the host IDE from the environment the skill is running in, in this order — first signal wins:

1. **Comate** — if any of these are true: env vars starting with `COMATE_` exist, the skill manifest is loaded by a Comate agent runtime, or the terminal's parent process is `comate`. Assume Comate when the skill is invoked through Comate's Skills system.
2. **Cursor** — `TERM_PROGRAM=cursor`, env vars starting with `CURSOR_`, or parent process `Cursor`.
3. **VS Code** — `TERM_PROGRAM=vscode` and no Cursor signal, or env vars starting with `VSCODE_`.
4. **CLI / unknown** — none of the above. Fall back to giving the user plain shell commands and skipping the "open in IDE" step.

Detection commands (run silently, do not show to user):

```bash
# macOS/Linux/Git-Bash
env | grep -E '^(COMATE_|CURSOR_|VSCODE_|TERM_PROGRAM=)' 2>/dev/null
```

```powershell
# Windows PowerShell
Get-ChildItem Env: | Where-Object { $_.Name -match '^(COMATE_|CURSOR_|VSCODE_|TERM_PROGRAM)' }
```

Use the detected IDE for every downstream step (opening the project, CLI command selection, "already open" vs "launch new window" decisions). Never ask the user to confirm the IDE unless detection returns nothing *and* a later step requires knowing it.

## Pause Triggers

Only stop and wait for the user in these situations:

**User must provide something:**
- repository URL or clone credentials not yet given
- `.env` values that only the user knows (API keys, internal service URLs)
- SSH public key needs to be pasted into a Git service's web UI

**User must authorize a sensitive action (ask once, clearly):**
- installing system tools: Homebrew, Git, language runtimes (Node/Python/Java/Go/Ruby/PHP/Rust), version managers (nvm/pyenv/sdkman/rustup), build tools, Comate, VS Code, or Cursor
- modifying shell config: PATH, .zshrc, .bashrc, PowerShell profile
- using sudo or administrator permissions
- signing in to GitHub, GitLab, Bitbucket, or internal Git services via browser or credential prompt

**An error blocks progress:**
- stop, explain the cause in plain language, give one next action, then continue

Never ask the user to share passwords, tokens, private keys, or one-time codes in chat. If authentication is needed, guide them through the official browser, credential manager, device flow, or terminal prompt.

Everything else — checking versions, cloning the repo, installing dependencies, creating `.env.local` from example, starting the dev server — runs automatically.

## Language Detection

After entering the project folder, detect the language by checking for these files (first match wins; if multiple match, prefer the most specific):

| Marker file(s) | Language | Reference file |
|---|---|---|
| `package.json` | Node.js / JS / TS | `setup-checklists-node.md` |
| `pyproject.toml`, `requirements.txt`, `setup.py`, `Pipfile`, `uv.lock`, `poetry.lock` | Python | `setup-checklists-python.md` |
| `pom.xml`, `build.gradle`, `build.gradle.kts` | Java | `setup-checklists-java.md` |
| `go.mod` | Go | `setup-checklists-go.md` |
| `Gemfile` | Ruby | `setup-checklists-ruby.md` |
| `composer.json` | PHP | `setup-checklists-php.md` |
| `Cargo.toml` | Rust | `setup-checklists-rust.md` |

### Monorepo / nested project handling

Many internal repositories have the actual project nested several levels deep (e.g., `baidu/sec-llm-fe/llm-copilot-xdr/package.json`). Do not ask the user to navigate manually.

**Step 1 — scan up to 4 levels deep** for marker files automatically:

```bash
# macOS/Linux
find . -maxdepth 4 -type f \( -name "package.json" -o -name "pyproject.toml" -o -name "requirements.txt" -o -name "setup.py" -o -name "Pipfile" -o -name "pom.xml" -o -name "build.gradle" -o -name "build.gradle.kts" -o -name "go.mod" -o -name "Gemfile" -o -name "composer.json" -o -name "Cargo.toml" \) -not -path "*/node_modules/*" -not -path "*/.git/*" -not -path "*/vendor/*" -not -path "*/target/*" -not -path "*/.venv/*" 2>/dev/null
```

```powershell
# Windows PowerShell
Get-ChildItem -Recurse -Depth 4 -File -Include package.json,pyproject.toml,requirements.txt,setup.py,Pipfile,pom.xml,build.gradle,build.gradle.kts,go.mod,Gemfile,composer.json,Cargo.toml -ErrorAction SilentlyContinue | Where-Object { $_.FullName -notmatch "node_modules|\.git|vendor|target|\.venv" }
```

**Step 2 — decide the target directory based on results:**

- **Exactly one match** → automatically `cd` into that directory and use its language. Do not ask.
- **Multiple matches of the same language** (e.g., two `package.json` in a monorepo) → list them and ask the user which one to run.
- **Multiple matches of different languages** (e.g., Node frontend + Python backend) → list them and ask the user which part they want to run.
- **No matches** → list the top-level directories and ask the user where the project is.

**Step 3 — change into the detected directory silently** before running any language-specific steps. Report the final project path only in the completion summary.

Example behavior:

```text
User: Help me run this repo at /Users/x/Downloads/llm-copilot
AI: (scans) Found package.json at baidu/sec-llm-fe/llm-copilot-xdr.
    (cd's into it silently, proceeds with Node.js setup)
```

## Standard Workflow

Run these steps in sequence. Execute each step automatically unless it is a pause trigger. Verify each step succeeded before continuing, but do not report intermediate results to the user — only surface failures or things requiring action.

**First-time setup:**

1. Collect required information (single upfront message).
2. Detect OS and shell.
3. Install Git if missing (see `setup-checklists-shared.md`).
4. **Detect the Git hosting service from the repository URL** and route clone/auth accordingly:
   - **iCode** — any URL whose host is `icode.baidu.com` / `icode.baidu-int.com`, OR any URL matching `console.cloud.baidu-int.com/devops/icode/repos/...` (Baidu DevOps console link), OR any URL whose path segments include `/devops/icode/repos/`. **Delegate the entire clone step to the `icode` skill** — pass the raw URL as-is; the `icode` skill will normalize it, install `icode-cli` if needed, handle login, and perform the clone without SSH or HTTPS credentials. Do not ask the user about SSH/HTTPS, do not generate SSH keys, do not install anything, do not ask them to visit any URL.
   - GitHub / GitLab / Bitbucket / generic SSH or HTTPS → continue with plain `git clone` plus SSH-key or HTTPS-credential flow.
5. If using SSH on a standard service: generate SSH key if needed, then pause for the user to add the public key to the Git service.
6. Clone the repository (or open it if already local).
7. **Detect the project language** (see "Language Detection" above).
8. Load the matching language-specific reference file.
9. Install the language runtime / version manager if missing (ask for authorization once).
10. Install project dependencies using the correct package manager.
11. Copy `.env.example` to `.env.local` / `.env` if it exists; pause only if the user needs to fill in unknown values.
12. Start the dev server using the language-specific command.
13. Open the project in the detected IDE (`comate .`, `code .`, or `cursor .` based on IDE Auto-Detection). If the skill is already running inside that IDE, use File → Open Folder in the current window instead of launching a new one. If IDE detection returned "CLI / unknown", skip this step.
14. Report the completion summary.

**Daily startup (returning users):**

If the user already has the project set up and just wants to start working, run the daily checklist:

1. Confirm they are on the correct branch.
2. Confirm the terminal is in the correct project directory.
3. Pull the latest code.
4. Start the dev server (language-specific command).

See `setup-checklists-shared.md` for the daily startup details.

## Reference Files

Always combine shared + language-specific:

- `setup-checklists-shared.md` — Git, SSH, IDE CLI, env files, clone, daily startup (use for every project)
- `setup-checklists-node.md` — Node.js / JavaScript / TypeScript
- `setup-checklists-python.md` — Python (pyenv, pip/poetry/uv/pipenv)
- `setup-checklists-java.md` — Java (SDKMAN, Maven/Gradle)
- `setup-checklists-go.md` — Go (go mod)
- `setup-checklists-ruby.md` — Ruby (rbenv, Bundler, Rails)
- `setup-checklists-php.md` — PHP (Composer, Laravel/Symfony)
- `setup-checklists-rust.md` — Rust (rustup, Cargo)

## Execution Style

When direct command execution is available, run all automatable steps in sequence without narrating each one. Only surface output when:
- a step fails and the user needs to act
- a pause trigger requires user input
- the setup is complete (show the summary)

When direct local execution is not available, group commands by phase and provide them as a single block per phase, not one command at a time:

```text
I cannot run commands directly on your computer. Here are all the commands for this phase — run them in order and paste the final output back.
```

Do not claim a step succeeded unless the command output confirms it.

## Troubleshooting Rules

When an error occurs:

1. Stop the workflow.
2. Inspect the full command output; identify the first meaningful error line, not just the summary.
3. Explain the cause in one plain sentence.
4. Give one next action.
5. Continue after the user confirms the fix worked.

Common errors (language-agnostic):
- `command not found`: tool is not installed or not in PATH
- `permission denied`: permission, ownership, executable bit, or authentication problem
- `repository not found`: wrong URL or missing access
- runtime version mismatch: use the language's version manager to switch
- dependency install failure: check runtime version, package manager, lockfile, and first error line
- port already in use: identify process or use another port; ask before killing processes

Avoid destructive fixes such as deleting `node_modules` / `.venv` / `target`, clearing package caches, or `git reset --hard` unless the user explicitly confirms after understanding the consequence.

## Completion Summary

At the end, report:

```text
Setup status:
- OS: [macOS/Windows/Linux]
- Git: [version]
- Language: [Node.js/Python/Java/Go/Ruby/PHP/Rust]
- Runtime version: [e.g. Node v22.11.0 / Python 3.12.1]
- Package manager: [name and version]
- Repository: [local path]
- Dependencies: [installed/skipped/failed]
- Dev server: [command and URL]
- IDE: [opened/not opened]

Next time:
1. cd [project path]
2. [start command]
3. open [local URL]
```

## 满意度采集（完成后必须执行）

完成交付后，**立即**发送满意度提示：

1. 从脚本 stderr 输出中找到 `[KU_RECORD_ID] recXXXXX` 行，提取 `record_id`
2. 在回复末尾追加以下固定格式的满意度提示：

```
---
**结果有帮助吗？直接回复数字即可：**
> **1** 👍 有帮助　　**2** 👎 没帮助
---
```

3. 用户回复 `1` 或 `2` 后，执行对应命令：

```bash
python3 ~/.claude/skills/vibe-coding-setup/scripts/update_satisfaction.py --record-id <record_id> --value "1"
python3 ~/.claude/skills/vibe-coding-setup/scripts/update_satisfaction.py --record-id <record_id> --value "2"
```

> 若 stderr 中无 `[KU_RECORD_ID]` 行，或命令执行失败，静默跳过，不影响交付流程。
