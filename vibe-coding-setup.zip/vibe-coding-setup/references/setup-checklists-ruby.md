# Ruby Checklist

Detection: project contains `Gemfile`.

## Check tools

```bash
ruby -v
gem -v
bundle -v
rbenv --version      # optional, recommended
```

## rbenv and Ruby

### macOS / Linux

Install rbenv:

```bash
# macOS
brew install rbenv ruby-build

# Debian/Ubuntu
sudo apt update && sudo apt install -y rbenv
git clone https://github.com/rbenv/ruby-build.git "$(rbenv root)"/plugins/ruby-build

# Fedora/RHEL
sudo dnf install -y rbenv ruby-build
```

Add to `~/.zshrc` or `~/.bashrc`:

```bash
eval "$(rbenv init - zsh)"          # or bash
```

Reload shell and verify:

```bash
source ~/.zshrc
rbenv --version
```

Install Ruby:

```bash
rbenv install 3.3.0         # or the version the project requires
rbenv global 3.3.0
ruby -v                     # Expected: ruby 3.3.0
```

If the project has `.ruby-version`:

```bash
rbenv install $(cat .ruby-version)
rbenv local $(cat .ruby-version)
```

### Windows

On Windows, install **RubyInstaller** via winget:

```powershell
winget install -e --id RubyInstallerTeam.RubyWithDevKit.3.3
```

Native rbenv does not support Windows. For serious Ruby/Rails work on Windows, use WSL and follow the macOS/Linux steps above.

## Install Bundler

```bash
gem install bundler
bundle -v
```

## Install dependencies

```bash
bundle install
```

Gems install to the Ruby version's gem path. Check `Gemfile.lock` is committed with the project.

## Start the project

### Rails (most common)

```bash
bin/rails server            # preferred, uses binstubs
# or
rails server
```

Default URL: `http://localhost:3000`.

Setup steps for fresh Rails projects:

```bash
bin/rails db:setup          # create + migrate + seed
bin/rails assets:precompile # if needed
```

### Sinatra / plain Rack

```bash
bundle exec rackup
# Default URL: http://localhost:9292
```

### Ruby script

```bash
bundle exec ruby <script>.rb
```
