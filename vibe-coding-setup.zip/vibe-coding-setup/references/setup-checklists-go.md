# Go Checklist

Detection: project contains `go.mod`.

## Check tools

```bash
go version
# Expected: go1.21.x or newer
```

## Install Go

### macOS

```bash
brew install go
```

If Homebrew is not installed, install Homebrew first or use the official installer from `https://go.dev/dl/`.

### Linux

```bash
# Debian/Ubuntu (may be older; check `go version` after install)
sudo apt update && sudo apt install -y golang-go

# Fedora/RHEL
sudo dnf install -y golang
```

For a newer version or when system package is too old, install from the official tarball:

```bash
curl -LO https://go.dev/dl/go1.22.0.linux-amd64.tar.gz
sudo rm -rf /usr/local/go && sudo tar -C /usr/local -xzf go1.22.0.linux-amd64.tar.gz
echo 'export PATH=$PATH:/usr/local/go/bin' >> ~/.bashrc
source ~/.bashrc
```

### Windows

Install via winget (no manual download needed):

```powershell
winget install -e --id GoLang.Go
```

After install, restart PowerShell and verify:

```powershell
go version
```

## Go version selection

Check `go.mod` for the `go` directive:

```bash
head -1 go.mod       # macOS/Linux
Get-Content go.mod -TotalCount 1   # Windows PowerShell
# Example: "go 1.21"
```

The installed Go version must be ≥ the version in `go.mod`.

If multiple Go versions are needed, use `gvm` (Linux/macOS) or download specific versions from go.dev/dl.

## Download dependencies

```bash
go mod download
# Or just run `go build` / `go run` — Go auto-downloads deps
```

Dependencies cache to `$GOPATH/pkg/mod` (default `~/go/pkg/mod`). First run can be slow on large projects.

## Build and run

### Standard patterns

```bash
go run ./cmd/<app-name>          # run a specific main package
go run main.go                   # if main.go is in the root
go build -o bin/app ./cmd/<app>  # build a binary
./bin/app                        # run the binary
```

### Common frameworks

- **Gin / Echo / Fiber** HTTP servers: usually listen on `http://localhost:8080`
- **gRPC** services: no HTTP UI, check logs for the listening port

Check the project README for the exact entry point — Go projects vary more than Node.js in layout.

## Tests

```bash
go test ./...
```
