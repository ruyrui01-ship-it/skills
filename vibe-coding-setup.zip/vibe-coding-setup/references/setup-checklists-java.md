# Java Checklist

Detection: project contains `pom.xml` (Maven) or `build.gradle` / `build.gradle.kts` (Gradle).

## Check tools

```bash
java -version
javac -version
mvn -v        # if Maven project
gradle -v     # if Gradle project
sdk version   # SDKMAN, optional
```

## JDK via SDKMAN

### macOS / Linux

SDKMAN is the easiest way to manage JDK versions.

Install SDKMAN with the official one-liner:

```bash
curl -s "https://get.sdkman.io" | bash
```

Activate in the current shell:

```bash
source "$HOME/.sdkman/bin/sdkman-init.sh"
sdk version
```

Install a JDK:

```bash
sdk list java                           # see available versions
sdk install java 21.0.2-tem             # Temurin 21 LTS, or match the project
java -version                           # Expected: 21.x.x
```

If the project has `.sdkmanrc`:

```bash
cd <project>
sdk env install
sdk env
```

### Windows

Install via winget:

```powershell
winget install -e --id EclipseAdoptium.Temurin.21.JDK
```

After install, restart PowerShell and verify:

```powershell
java -version
echo $env:JAVA_HOME
```

## Build tool selection

- `pom.xml` → **Maven**
- `build.gradle` / `build.gradle.kts` → **Gradle**
- `gradlew` wrapper present → **always use `./gradlew`** (not global `gradle`) to match the project's expected Gradle version
- `mvnw` wrapper present → **always use `./mvnw`** (not global `mvn`)

## Install dependencies

Maven:

```bash
./mvnw install                 # with wrapper
mvn install                    # fallback to global
```

Gradle:

```bash
./gradlew build                # with wrapper
gradle build                   # fallback to global
```

Windows PowerShell:

```powershell
.\mvnw.cmd install
.\gradlew.bat build
```

Dependencies download to the user's local Maven/Gradle cache (`~/.m2` or `~/.gradle`). First run takes time — warn the user.

## Start the project

### Spring Boot (most common)

```bash
./mvnw spring-boot:run              # Maven
./gradlew bootRun                   # Gradle
```

Default URL: `http://localhost:8080`.

### Plain Java with main class

```bash
./mvnw exec:java -Dexec.mainClass="com.example.Main"
./gradlew run
```

### Run a built JAR

```bash
java -jar target/<app>.jar          # Maven output
java -jar build/libs/<app>.jar      # Gradle output
```
