# Node.js / JavaScript / TypeScript Checklist

Detection: project contains `package.json`. Lockfile determines package manager.

## Check tools

```bash
node -v
npm -v
yarn -v
pnpm -v
```

## nvm and Node.js

### macOS / Linux

Check nvm:

```bash
command -v nvm
nvm --version
```

If nvm is missing, install it with the official one-liner:

```bash
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.3/install.sh | bash
```

Activate nvm immediately without restarting the shell:

```bash
. "$HOME/.nvm/nvm.sh"
nvm --version
# Expected output: 0.40.3
```

Install and use Node.js:

```bash
nvm install --lts
nvm use --lts
node -v    # Expected: v22.x.x or similar LTS
npm -v     # Expected: 10.x.x or similar
```

If the project has `.nvmrc`:

```bash
nvm install
nvm use
node -v    # Expected to match .nvmrc
```

### Windows

On Windows, install **nvm-windows** from the official GitHub Releases page:

```
https://github.com/coreybutler/nvm-windows/releases/latest
```

Download `nvm-setup.exe` and run it, then restart PowerShell.

```powershell
nvm version
nvm install lts
nvm use lts
node -v
npm -v
```

If `nvm use` requires administrator permission, explain why and ask before proceeding.

## Package manager selection

Based on lockfile:
- `yarn.lock` → `yarn install`
- `package-lock.json` → `npm install`
- `pnpm-lock.yaml` → `pnpm install`
- `packageManager` field in `package.json` overrides the default when present

Do not mix package managers.

## Install Yarn / pnpm if needed

```bash
corepack enable
yarn -v
pnpm -v
```

If Corepack is unavailable:

```bash
npm install -g yarn
# or
npm install -g pnpm
```

Ask before global installs.

## Node version selection

Priority order:
1. `.nvmrc`
2. `.node-version`
3. README setup instructions
4. `engines.node` in `package.json`
5. Current LTS (mention the assumption)

## Install dependencies

```bash
yarn install       # or npm install / pnpm install
```

## Start dev server

Inspect scripts:

```bash
cat package.json              # macOS/Linux
Get-Content package.json      # Windows PowerShell
npm pkg get scripts           # cross-platform
```

Common start commands (in order of probability):

```bash
yarn dev
npm run dev
pnpm dev
yarn start
npm start
```

Open the URL shown in the terminal, often `http://localhost:3000` or `http://localhost:5173`.
