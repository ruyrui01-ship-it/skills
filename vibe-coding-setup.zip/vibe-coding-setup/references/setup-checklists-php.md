# PHP Checklist

Detection: project contains `composer.json`.

## Check tools

```bash
php -v
composer -V
```

## Install PHP

### macOS

```bash
brew install php       # requires Homebrew, ask first
```

### Linux

```bash
# Debian/Ubuntu
sudo apt update && sudo apt install php php-cli php-mbstring php-xml php-curl

# Fedora/RHEL
sudo dnf install php php-cli php-mbstring php-xml
```

### Windows

Download PHP from windows.php.net or use XAMPP / Laragon for a bundled stack. Add PHP to PATH.

## PHP version selection

Check `composer.json` for `require.php`:

```bash
grep '"php"' composer.json
```

Installed PHP must satisfy this constraint. For multi-version management, use `phpenv` (macOS/Linux) or re-install the required version.

## Install Composer

### macOS

```bash
brew install composer
```

### Linux / Windows

Install Composer globally:

```bash
# Linux / macOS
curl -sS https://getcomposer.org/installer | php -- --install-dir=/usr/local/bin --filename=composer
```

```powershell
# Windows — use winget
winget install -e --id Composer.Composer
```

Verify:

```bash
composer -V
```

## Install dependencies

```bash
composer install
```

Installs into `vendor/` directory. First run can be slow.

## Environment setup

Most Laravel/Symfony projects need `.env`:

```bash
cp .env.example .env
php artisan key:generate          # Laravel only
```

Edit `.env` for database and app settings.

## Start the project

### Laravel

```bash
php artisan serve
# Default URL: http://localhost:8000
```

With a database:

```bash
php artisan migrate
php artisan db:seed     # if seeders exist
```

### Symfony

```bash
symfony server:start
# or
php -S localhost:8000 -t public/
```

### Plain PHP

```bash
php -S localhost:8000 -t public/
```
