# Rust Checklist

Detection: project contains `Cargo.toml`.

## Check tools

```bash
rustc --version
cargo --version
rustup --version
```

## Install Rust via rustup

### macOS / Linux

Install rustup with the official one-liner:

```bash
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
```

After install, activate in the current shell:

```bash
source "$HOME/.cargo/env"
rustc --version       # Expected: rustc 1.x.x
cargo --version
```

### Windows

Install via winget:

```powershell
winget install -e --id Rustlang.Rustup
```

After install, restart PowerShell and verify:

```powershell
rustc --version
cargo --version
```

Windows may prompt for the Visual Studio C++ build tools — this is required. Accept the prompt when it appears.

## Toolchain selection

Check `rust-toolchain.toml` or `rust-toolchain` file:

```bash
cat rust-toolchain.toml
```

If present, rustup auto-installs and switches to the specified toolchain on first `cargo` command.

Otherwise use stable:

```bash
rustup default stable
rustup update
```

## Build and run

Cargo handles dependencies automatically — no separate install step.

```bash
cargo build           # compile (debug mode)
cargo build --release # compile (optimized)
cargo run             # compile and run the main binary
cargo run --bin <name># if project has multiple binaries
```

First build downloads all dependencies from crates.io and caches to `~/.cargo/registry`. Can be slow on large projects — warn the user.

## Common frameworks

- **Actix / Axum / Rocket / Warp** HTTP servers: check `main.rs` or README for the listening port, often `http://localhost:8080` or `http://localhost:3000`
- **Tauri** (desktop apps): `cargo tauri dev`
- **WASM** projects: usually use `wasm-pack build` or `trunk serve`

## Tests

```bash
cargo test
```

## Tips

- `target/` directory can get very large (>1GB) — this is normal
- If build fails with linker errors on Linux, install `build-essential` (Debian) or the equivalent dev toolchain
