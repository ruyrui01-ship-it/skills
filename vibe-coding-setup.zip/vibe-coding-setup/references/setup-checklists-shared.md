# Shared Setup Checklists

Language-agnostic setup steps: Git, SSH, IDE, env files, clone, daily startup. Combine with the language-specific checklist for a full setup.

## Git

### macOS

If Git is missing, first try:

```bash
xcode-select --install
```

If Homebrew is installed:

```bash
brew install git
```

Ask before installing Homebrew — it changes system-level developer tooling.

### Windows

Guide the user to install Git for Windows from the official Git website. After installation, restart the terminal and verify:

```powershell
git --version
```

### Linux

```bash
# Debian/Ubuntu
sudo apt update && sudo apt install git

# Fedora/RHEL
sudo dnf install git
```

Verify:

```bash
git --version
```

## SSH Key Setup (if using SSH cloning)

Generate an SSH key pair if one does not exist:

```bash
ssh-keygen -t rsa
# Press Enter to accept defaults — do not set a passphrase unless required
```

View and copy the public key:

```bash
cat ~/.ssh/id_rsa.pub
# Copy the full output starting with "ssh-rsa ..."
```

Paste the public key into the Git service's SSH key settings page (GitHub, GitLab, iCode, or equivalent). Never share the private key (`~/.ssh/id_rsa`) or paste it into chat.

Verify the connection:

```bash
ssh -T git@github.com      # GitHub
ssh -T git@gitlab.com      # GitLab
# Expected: a welcome message with your username
```

If SSH setup is too complex, HTTPS cloning is a simpler alternative — use the HTTPS clone URL instead.

## Clone repository

### Detect the Git hosting service

Before cloning, inspect the repository URL and route accordingly:

| URL pattern | Handling |
|---|---|
| Host is `icode.baidu.com` / `icode.baidu-int.com` | Baidu iCode — delegate entirely to the `icode` skill |
| URL contains `/devops/icode/repos/` (e.g. `console.cloud.baidu-int.com/devops/icode/repos/baidu/...`) | Baidu iCode console link — same as above, delegate to the `icode` skill |
| `github.com` / `gitlab.com` / `bitbucket.org` / other standard Git hosts | Plain `git clone` with SSH key or HTTPS credentials |

### Baidu iCode repositories

Delegate to the `icode` skill and pass the URL through as-is — including Baidu DevOps console links like `https://console.cloud.baidu-int.com/devops/icode/repos/baidu/sec-llm-fe/llm-copilot-xdr/tree/master`. The `icode` skill will:

- normalize the URL (strip `/tree/<branch>`, extract the repo path)
- install `icode-cli` if needed
- handle login
- clone the repo using its built-in auth (no SSH key, no HTTPS credentials required from the user)

Do not ask the user for SSH/HTTPS preference, do not generate SSH keys, do not ask them to visit any URL.

After the `icode` skill finishes, resume the vibe-coding-setup workflow at "Detect project language".

### Standard Git repositories

```bash
git clone <repo-url>
cd <repo-folder>
```

If authentication fails:
- HTTPS usually opens a browser or credential prompt
- SSH requires an SSH key registered with the Git service
- never paste passwords, tokens, or private keys into chat

## Environment files

Check if an example env file exists:

```bash
# macOS/Linux
ls .env* 2>/dev/null
```

```powershell
# Windows PowerShell
Get-ChildItem -Filter ".env*"
```

If an example file exists, copy it:

```bash
# macOS/Linux
cp .env.example .env.local
```

```powershell
# Windows PowerShell
Copy-Item .env.example .env.local
```

Open `.env.local` in the IDE and fill in required values based on the project README. Never ask the user to paste secret values into chat — guide them to edit the file directly.

## IDE: Comate, VS Code, Cursor

**Comate is the primary IDE target for this skill** — most users running this skill are already inside Comate. If the skill is executing in Comate's terminal, the IDE is already open; "opening the project" usually means opening the folder in the current window via File → Open Folder, not launching a new process.

Download Comate from the official documentation: https://cloud.baidu.com/doc/COMATE/

### Comate CLI

If a `comate` CLI is available, open a project with:

```bash
comate .
```

If the CLI is not in PATH, open Comate manually, then use File → Open Folder to navigate to the project path.

### VS Code / Cursor CLI

#### macOS / Linux

If VS Code is installed but `code` is unavailable:

1. Open VS Code.
2. Press Command+Shift+P (macOS) or Ctrl+Shift+P (Linux).
3. Run `Shell Command: Install 'code' command in PATH`.
4. Restart the terminal.
5. Verify with `code --version`.

For Cursor, the same Command Palette step installs the `cursor` command.

#### Windows

Enable the PATH option during VS Code/Cursor installation or reinstall with PATH enabled, then restart PowerShell.

## Daily Startup Checklist

For users who already have the project set up. Run these 4 checks every time before starting work.

### Step 1: Confirm current branch

```bash
git branch --show-current
# Expected output: your working branch name
```

Switch branches if needed:

```bash
git checkout <branch-name>
```

### Step 2: Confirm correct project directory

```bash
pwd                                 # macOS/Linux
Get-Location                        # Windows PowerShell
# Expected output: the full path to your project folder
```

If not in the right folder, auto-locate it by searching for the project marker file (package.json, pyproject.toml, go.mod, etc.) up to 4 levels deep — do not ask the user to `cd` layer by layer:

```bash
# macOS/Linux — find the nearest project root
find . -maxdepth 4 -type f \( -name "package.json" -o -name "pyproject.toml" -o -name "go.mod" -o -name "pom.xml" -o -name "Cargo.toml" -o -name "Gemfile" -o -name "composer.json" \) -not -path "*/node_modules/*" -not -path "*/.git/*" 2>/dev/null
```

Then `cd` into the directory containing the marker file automatically.

### Step 3: Pull the latest code

```bash
git pull
# Expected output: "Already up to date." or a list of updated files
```

If there are merge conflicts, stop and ask for help.

### Step 4: Start the dev server

Use the language-specific start command — see the appropriate `setup-checklists-<language>.md` file.

If startup fails with a missing module/dependency error, reinstall dependencies first (again, language-specific command).

## Safe Troubleshooting Commands

### Show current directory

```bash
pwd                      # macOS/Linux
Get-Location             # Windows PowerShell
```

### List project files

```bash
ls                       # macOS/Linux
Get-ChildItem            # Windows PowerShell
```

### Check tool path

```bash
which <tool>             # macOS/Linux
where.exe <tool>         # Windows PowerShell
```
