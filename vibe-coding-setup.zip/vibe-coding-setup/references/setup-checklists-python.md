# Python Checklist

Detection: project contains any of `requirements.txt`, `pyproject.toml`, `setup.py`, `Pipfile`, `poetry.lock`, `uv.lock`.

## Check tools

```bash
python3 --version
pip3 --version
pyenv --version     # optional but recommended
poetry --version    # optional
uv --version        # optional
```

## pyenv and Python

### macOS / Linux

Check pyenv:

```bash
command -v pyenv
pyenv --version
```

If pyenv is missing, install it:

```bash
# macOS (preferred)
brew install pyenv

# Linux / macOS alternative (no Homebrew)
curl -fsSL https://pyenv.run | bash
```

After install, pyenv needs to be added to the shell. Add to `~/.zshrc` (or `~/.bashrc`):

```bash
export PYENV_ROOT="$HOME/.pyenv"
export PATH="$PYENV_ROOT/bin:$PATH"
eval "$(pyenv init -)"
```

Reload the shell:

```bash
source ~/.zshrc
pyenv --version
# Expected output: pyenv 2.x.x
```

Install Python:

```bash
pyenv install 3.12   # or the version the project requires
pyenv global 3.12
python3 --version    # Expected: Python 3.12.x
```

If the project has `.python-version`:

```bash
pyenv install
python3 --version    # Expected to match .python-version
```

### Windows

On Windows, install **pyenv-win** with PowerShell:

```powershell
Invoke-WebRequest -UseBasicParsing -Uri "https://raw.githubusercontent.com/pyenv-win/pyenv-win/master/pyenv-win/install-pyenv-win.ps1" -OutFile "./install-pyenv-win.ps1"
./install-pyenv-win.ps1
```

Then restart PowerShell.

```powershell
pyenv --version
pyenv install 3.12
pyenv global 3.12
python --version
```

Alternative on Windows: install Python directly from python.org and ensure "Add Python to PATH" is checked during install.

## Package manager selection

Detect in this order (most specific wins):
- `poetry.lock` → **Poetry** (`poetry install`)
- `uv.lock` → **uv** (`uv sync`)
- `Pipfile.lock` → **Pipenv** (`pipenv install`)
- `pyproject.toml` without lockfile → check `[tool.poetry]` / `[tool.uv]` / `[build-system]` sections
- `requirements.txt` → **pip** (`pip install -r requirements.txt`)
- `setup.py` only → **pip** (`pip install -e .`)

## Virtual environment

Always use a virtual environment. Project tooling usually handles this automatically (Poetry, uv, Pipenv). For raw pip projects:

```bash
python3 -m venv .venv
source .venv/bin/activate          # macOS/Linux
.venv\Scripts\Activate.ps1         # Windows PowerShell
```

Verify:

```bash
which python                        # macOS/Linux
where.exe python                    # Windows PowerShell
# Expected: path inside .venv/
```

## Install dependencies

```bash
# pip
pip install -r requirements.txt

# Poetry
poetry install

# uv
uv sync

# Pipenv
pipenv install
```

## Start the project

Inspect project README or entry points. Common patterns:

```bash
# FastAPI
uvicorn main:app --reload

# Flask
flask run

# Django
python manage.py runserver

# Streamlit
streamlit run app.py

# Plain script
python main.py
```

With Poetry / uv / Pipenv, prefix with the tool:

```bash
poetry run uvicorn main:app --reload
uv run python main.py
pipenv run flask run
```

Default dev server URL is often `http://localhost:8000` (FastAPI/Django) or `http://localhost:5000` (Flask).
