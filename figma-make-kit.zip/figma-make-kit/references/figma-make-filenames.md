# Figma Make Default Filenames

These are the component files Figma Make generates by default in `src/app/components/ui/`.
When a design component maps to one of these, use the **exact filename** so the drop-in
replacement works without path changes in any existing imports.

## Component Files

| Filename | | Filename | | Filename |
|---|---|---|---|---|
| `accordion.tsx` | | `dialog.tsx` | | `scroll-area.tsx` |
| `alert-dialog.tsx` | | `drawer.tsx` | | `select.tsx` |
| `alert.tsx` | | `dropdown-menu.tsx` | | `separator.tsx` |
| `aspect-ratio.tsx` | | `form.tsx` | | `sheet.tsx` |
| `avatar.tsx` | | `hover-card.tsx` | | `sidebar.tsx` |
| `badge.tsx` | | `input-otp.tsx` | | `skeleton.tsx` |
| `breadcrumb.tsx` | | `input.tsx` | | `slider.tsx` |
| `button.tsx` | | `label.tsx` | | `sonner.tsx` |
| `calendar.tsx` | | `menubar.tsx` | | `switch.tsx` |
| `card.tsx` | | `navigation-menu.tsx` | | `table.tsx` |
| `carousel.tsx` | | `pagination.tsx` | | `tabs.tsx` |
| `chart.tsx` | | `popover.tsx` | | `textarea.tsx` |
| `checkbox.tsx` | | `progress.tsx` | | `toggle-group.tsx` |
| `collapsible.tsx` | | `radio-group.tsx` | | `toggle.tsx` |
| `command.tsx` | | `resizable.tsx` | | `tooltip.tsx` |
| `context-menu.tsx` | | | | |

## Utility Files (do NOT overwrite)

- `use-mobile.ts` — mobile detection hook
- `utils.ts` — shared utilities (`cn`, etc.)

These are shared dependencies. Only replace if the user explicitly requests it.

## Custom Components

If a design component has no Figma Make equivalent, create a new kebab-case filename:
`steps.tsx`, `tag-group.tsx`, `stat-card.tsx`, `empty-state.tsx`, etc.
Place it in the same `src/app/components/ui/` directory.
