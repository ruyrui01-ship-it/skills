# Frontend Standards Questions

When the user has no standards document, send all of the following in a single message.

---

> 在开始之前，我需要了解你的前端技术栈，这样生成的内容才能直接用于你的项目：
>
> 1. **组件库**：你使用哪个组件库？（antd v5 / antd v4 / MUI / shadcn/ui / 无，直接用原生 / **内部自研组件库** / 其他）
> 2. **样式方案**：样式怎么写？（CSS Modules / Tailwind / styled-components / 其他）
> 3. **文件命名**：组件文件命名规范？（PascalCase 如 `Button.tsx` / kebab-case 如 `button.tsx`）
> 4. **目录结构**：组件怎么组织？（每个组件独立目录 / 所有组件平铺在一个文件夹 / 按功能分层）
> 5. **构建工具**：用什么构建？（Vite / CRA / Next.js / 其他）
>
> 如果某项还没决定，直接说"未定"就好。

---

## Minimum Required to Proceed

Must confirm before Step 2:
- Component library + version (determines token injection method and TSX patterns)
- Style approach (determines how CSS overrides are written)

## Inference Rules

| User says | Infer |
|-----------|-------|
| "standard antd" (no version) | antd v5 |
| "CSS Modules" | file naming: same stem + `.module.css` |
| "Tailwind" | adapt output to `@layer base` CSS variable injection; note oklch conflict risk |
| "no preference" on directory | flat structure: all components in `ui/` |
| "Next.js" | add server/client component boundary notes in setup.md |
| "shadcn/ui" | filenames are already kebab-case; skip ConfigProvider; CSS variables in `globals.css` |

## Proprietary Library Detection

If the user names a component library that is NOT in the known list (antd, MUI, shadcn/ui, Chakra, Radix), treat it as a **proprietary/internal library** and send a follow-up in the same message:

> 看起来你们使用的是内部自研组件库，需要补充以下信息才能正确生成 Kit：
>
> a. **npm 包名 / import 路径**？（例如 `@company/ui` 或 `@team/design-system`）
> b. **组件库的文档或代码在哪里**？优先级从高到低，提供任意一种即可：
>    - 组件库安装在当前项目的路径（如 `node_modules/@company/ui`）
>    - 组件库源码在本地的路径（如 `/Users/xxx/repos/design-system/src`）
>    - 公网可访问的文档地址（如 `https://design.company.com/components`）
>    - 内网文档地址（需要你把核心组件的 Props 说明复制粘贴出来）
> c. **主题注入方式**？（自定义 ThemeProvider / 全局 CSS 变量 / 无需注入 / 不确定）
> d. **有现成的组件使用示例吗**？粘贴 1-2 个真实业务代码片段会大幅提升生成质量

### Source resolution — how to read library information

After user responds, use the following resolution order:

**1. Local path (node_modules or source)**
The most reliable source. Use `Glob` + `Read` to navigate the package:
```
Priority read targets (in order):
  node_modules/@company/ui/index.d.ts       ← all exports and types in one file
  node_modules/@company/ui/dist/index.d.ts
  node_modules/@company/ui/types/index.d.ts
  node_modules/@company/ui/src/Button/index.tsx  ← source if no .d.ts
```
Search strategy:
- `Glob`: `node_modules/@company/ui/**/*.d.ts` to find type files
- `Grep`: search for `export interface ButtonProps` or `export type` to find prop definitions
- Read only the components needed for Kit (Button, Input, Select, Table, Modal — core set)
- Do NOT read the entire library; scope to components that appear in the Figma design

**2. Public documentation URL**
Use `WebFetch` with a targeted prompt:
```
prompt: "Extract all component names, their props (name, type, default value),
and any variant/enum values. Focus on: Button, Input, Select, Table, Modal."
```
Fetch individual component pages if the doc site has per-component URLs.
If a single index page links to all components, fetch that first to discover URLs.

**3. Internal / authenticated URL (intranet)**
`WebFetch` will fail for authenticated URLs (VPN-gated, login-required, etc.).
When this happens, tell the user:
> 内网文档我无法直接访问。请把以下组件的 Props 表格复制粘贴过来（截图也行，我可以识别）：
> Button、Input、Select、Table、Modal
> 只需要 Props 类型定义部分，不需要示例代码。

**4. No source available**
Infer API from usage examples provided in step (d).
Mark every inferred prop in `components.md` with `[inferred]` so the user knows to verify.

### After reading library source

Extract per component:
- All exported prop names and their TypeScript types
- Default values (from defaultProps or function parameter defaults)
- Enum values for union type props (especially `type`, `variant`, `size`, `status`)
- The exact import statement

This feeds directly into:
- `components.md` props tables (Step 3)
- TSX example files — all variant comments (Step 4)
- `setup.md` install + import section (Step 3)

If user cannot provide any source: proceed with only (a)(c)(d). Note in `components.md` header:
`> ⚠️ API details inferred from usage examples only — verify props against library source before using.`
