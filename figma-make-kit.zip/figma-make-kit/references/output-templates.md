# Output Templates

## Table of Contents
1. [token.json](#tokenjson)
2. [theme.css](#themecss)
3. [theme.config.ts (antd v5)](#themeconfigts-antd-v5)
4. [Guidelines.md](#guidelinesmd)
5. [tokens.md](#tokensmd)
6. [components.md — known library](#componentsmd--known-library)
7. [components.md — proprietary library](#componentsmd--proprietary-library)
8. [setup.md](#setupmd)
9. [Component TSX — CSS Modules stack](#component-tsx--css-modules-stack)
10. [Component CSS Module](#component-css-module)
11. [Component TSX — Less/BEM stack](#component-tsx--lessbem-stack)
12. [Component CSS (converted from Less)](#component-css-converted-from-less)
13. [Component TSX — Proprietary library](#component-tsx--proprietary-library)

---

## token.json

W3C Design Token format. Group by category. Values from Figma variables (Path A) or inferred (Path B).

```json
{
  "color": {
    "brand": {
      "primary":   { "$value": "#1677ff", "$type": "color" },
      "secondary": { "$value": "#4096ff", "$type": "color" }
    },
    "neutral": {
      "bg":  { "$value": "#f5f5f5", "$type": "color" },
      "100": { "$value": "#f5f5f5", "$type": "color" },
      "900": { "$value": "#141414", "$type": "color" }
    },
    "semantic": {
      "success": { "$value": "#52c41a", "$type": "color" },
      "warning": { "$value": "#faad14", "$type": "color" },
      "error":   { "$value": "#ff4d4f", "$type": "color" }
    }
  },
  "spacing": {
    "1": { "$value": "4px",  "$type": "dimension" },
    "2": { "$value": "8px",  "$type": "dimension" },
    "4": { "$value": "16px", "$type": "dimension" },
    "6": { "$value": "24px", "$type": "dimension" }
  },
  "typography": {
    "size": {
      "sm": { "$value": "12px", "$type": "dimension" },
      "md": { "$value": "14px", "$type": "dimension" },
      "lg": { "$value": "16px", "$type": "dimension" },
      "xl": { "$value": "20px", "$type": "dimension" }
    },
    "weight": {
      "regular":  { "$value": "400", "$type": "number" },
      "medium":   { "$value": "500", "$type": "number" },
      "semibold": { "$value": "600", "$type": "number" }
    }
  },
  "radius": {
    "sm": { "$value": "4px",  "$type": "dimension" },
    "md": { "$value": "8px",  "$type": "dimension" },
    "lg": { "$value": "16px", "$type": "dimension" }
  }
}
```

---

## theme.css

> **HEX not oklch**: Figma Make's default theme.css uses oklch (Tailwind v4 format).
> This file uses HEX — extracted directly from Figma variables or pages. Do NOT convert to oklch.
> Component library theme APIs (antd ConfigProvider, MUI createTheme) do not accept oklch.

```css
/* Auto-generated from Figma. Do not edit manually. */
:root {
  /* Color - Brand */
  --color-brand-primary:   #1677ff;
  --color-brand-secondary: #4096ff;

  /* Color - Neutral */
  --color-neutral-bg:  #f5f5f5;
  --color-neutral-100: #f5f5f5;
  --color-neutral-900: #141414;

  /* Color - Semantic */
  --color-success: #52c41a;
  --color-warning: #faad14;
  --color-error:   #ff4d4f;

  /* Spacing */
  --spacing-1: 4px;
  --spacing-2: 8px;
  --spacing-4: 16px;
  --spacing-6: 24px;

  /* Typography */
  --font-size-sm: 12px;
  --font-size-md: 14px;
  --font-size-lg: 16px;
  --font-size-xl: 20px;
  --font-weight-regular:  400;
  --font-weight-medium:   500;
  --font-weight-semibold: 600;

  /* Radius */
  --radius-sm: 4px;
  --radius-md: 8px;
  --radius-lg: 16px;
}
```

---

## theme.config.ts (antd v5)

```ts
// Maps CSS variables to antd v5 ConfigProvider theme tokens.
// Import this in App.tsx and pass to <ConfigProvider theme={antdTheme}>.
export const antdTheme = {
  token: {
    colorPrimary:    '#1677ff', // var(--color-brand-primary)
    colorSuccess:    '#52c41a', // var(--color-success)
    colorWarning:    '#faad14', // var(--color-warning)
    colorError:      '#ff4d4f', // var(--color-error)
    borderRadius:    8,         // --radius-md in px (number, not string)
    fontSize:        14,        // --font-size-md in px (number, not string)
    colorBgContainer: '#ffffff',
  },
  components: {
    Button: { borderRadius: 8 },
  },
};
```

> Note: antd v5 ConfigProvider `token` values must be raw hex strings or numbers, not `var()` references.
> Keep the comment mapping to the CSS variable name for traceability.

---

## Guidelines.md

```markdown
# Design System Guidelines

> This file is the primary AI instruction entry point for Figma Make.
> All generated code must follow these rules.

## Component Library
- Use **[ComponentLib] v[X]** exclusively
- NEVER use [alternative libs] when an equivalent component exists
- Import from: `import { ComponentName } from '[lib]'`

## Styling
- Use **[CSS approach]** for all custom styles
- NEVER use inline styles (`style={{}}`)
- NEVER hardcode color, spacing, radius, or font values
- All design values come from `src/styles/theme.css` as CSS variables

## Design Tokens
- Use semantic tokens: `var(--color-brand-primary)` not `#1677ff`
- See [tokens.md](tokens.md) for the full token reference and usage rules

## File & Directory Conventions
- [naming convention from user's standards]
- [directory structure from user's standards]
- Component entry: `src/app/components/ui/`

## References
- Token usage rules: [tokens.md](tokens.md)
- Component mapping: [components.md](components.md)
- Environment setup: [setup.md](setup.md)
```

---

## tokens.md

```markdown
# Token Reference

## Color Tokens

| Token | Value | Usage |
|-------|-------|-------|
| `--color-brand-primary` | #1677ff | Primary actions, links, focus rings |
| `--color-neutral-bg`    | #f5f5f5 | Page backgrounds, subtle containers |
| `--color-neutral-900`   | #141414 | Primary text |
| `--color-success`       | #52c41a | Success states |
| `--color-warning`       | #faad14 | Caution states |
| `--color-error`         | #ff4d4f | Error / destructive states |

### DO
```css
color: var(--color-brand-primary);
background-color: var(--color-neutral-bg);
```

### NEVER
```css
color: #1677ff;   /* hardcoded — use token */
color: blue;      /* generic — use token */
```

## Spacing Tokens

| Token | Value | Usage |
|-------|-------|-------|
| `--spacing-1` | 4px  | Tight gaps, icon padding |
| `--spacing-2` | 8px  | Internal component padding |
| `--spacing-4` | 16px | Standard section spacing |
| `--spacing-6` | 24px | Large section gaps |

## Typography Tokens

| Token | Value | Usage |
|-------|-------|-------|
| `--font-size-sm` | 12px | Labels, captions |
| `--font-size-md` | 14px | Body text, inputs |
| `--font-size-lg` | 16px | Subheadings |
| `--font-size-xl` | 20px | Page titles |

## Radius Tokens

| Token | Value | Usage |
|-------|-------|-------|
| `--radius-sm` | 4px | Tags, chips |
| `--radius-md` | 8px | Buttons, inputs, cards |
| `--radius-lg` | 16px | Modals, large containers |

## Special Handling

- Font weight values from Figma are unitless → use as-is in CSS (`font-weight: 600`)
- Shadow tokens require full shorthand: `box-shadow: 0 2px 8px rgba(0,0,0,.15)`
- antd v5 ConfigProvider token values must be raw numbers/hex, not `var()` references
```

---

## components.md — known library

```markdown
# Component Mapping

## Figma → Framework Component Map

| Figma Component    | Framework Component          | Import |
|--------------------|------------------------------|--------|
| Button/Primary     | `<Button type="primary">`    | `import { Button } from 'antd'` |
| Button/Default     | `<Button>`                   | `import { Button } from 'antd'` |
| Button/Danger      | `<Button danger>`            | `import { Button } from 'antd'` |
| Input/Default      | `<Input>`                    | `import { Input } from 'antd'` |
| Input/Search       | `<Input.Search>`             | `import { Input } from 'antd'` |
| Select             | `<Select>`                   | `import { Select } from 'antd'` |
| Checkbox           | `<Checkbox>`                 | `import { Checkbox } from 'antd'` |
| Switch             | `<Switch>`                   | `import { Switch } from 'antd'` |
| Modal              | `<Modal>`                    | `import { Modal } from 'antd'` |
| Drawer             | `<Drawer>`                   | `import { Drawer } from 'antd'` |
| Table              | `<Table>`                    | `import { Table } from 'antd'` |
| Tag                | `<Tag>`                      | `import { Tag } from 'antd'` |

## Composition Rules

- **Wrap** only when adding design-system-specific styling (CSS Module override)
- **Use directly** for standard use cases without extra wrapping
- **Never recreate** what the component library already provides natively
```

---

## setup.md

```markdown
# Environment Setup

## 1. Install Dependencies
```bash
npm install [component-lib]@[version]
```

## 2. Import theme.css
In your app entry point (`src/main.tsx` or `src/App.tsx`):
```tsx
import './styles/theme.css';
```

## 3. Configure ThemeProvider
```tsx
import { ConfigProvider } from 'antd';
import { antdTheme } from './styles/theme.config';

export default function App() {
  return (
    <ConfigProvider theme={antdTheme}>
      <RouterProvider router={router} />
    </ConfigProvider>
  );
}
```

## 4. Style File Convention
- All custom styles use CSS Modules: `ComponentName.module.css`
- Import: `import styles from './component-name.module.css'`
- Never use inline styles or hardcoded design values
```

---

## Component TSX — CSS Modules stack

```tsx
import React from 'react';
import { Button as AntButton, ButtonProps as AntButtonProps } from 'antd';
import styles from './button.module.css';

export interface ButtonProps extends AntButtonProps {
  variant?: 'primary' | 'default' | 'ghost' | 'danger';
}

const Button: React.FC<ButtonProps> = ({ variant = 'default', className, ...props }) => {
  const variantClass = styles[variant] ?? '';
  return (
    <AntButton
      type={variant === 'primary' ? 'primary' : 'default'}
      danger={variant === 'danger'}
      className={`${variantClass} ${className ?? ''}`.trim()}
      {...props}
    />
  );
};

export default Button;
```

---

## Component CSS Module

```css
/* button.module.css — override antd tokens using CSS variables only */

.primary {
  --ant-color-primary: var(--color-brand-primary);
  border-radius: var(--radius-md);
}

.default {
  border-radius: var(--radius-md);
}

.ghost {
  border-radius: var(--radius-md);
  border-color: var(--color-brand-primary);
  color: var(--color-brand-primary);
}

.danger {
  border-radius: var(--radius-md);
}
```

---

## Component TSX — Less/BEM stack

> Use this pattern when the project's style approach is Less + BEM (e.g. antd + enterprise console).
> The `.css` file is plain CSS — not Less — because Figma Make only accepts `.css`.

```tsx
import { useCallback } from 'react';
import { Button as AntButton } from 'antd';
import type { ButtonProps as AntButtonProps } from 'antd';
import classnames from 'classnames';
import './button.css';

export interface ButtonProps extends AntButtonProps {
  variant?: 'primary' | 'default' | 'danger' | 'link' | 'text';
}

const Button = ({
  variant = 'default',
  className,
  ...props
}: ButtonProps) => {
  const variantClass = classnames({
    'comp-button': true,
    [`comp-button-${variant}`]: true,
  });

  return (
    <AntButton
      type={
        variant === 'primary' ? 'primary'
        : variant === 'link' ? 'link'
        : variant === 'text' ? 'text'
        : 'default'
      }
      danger={variant === 'danger'}
      className={`${variantClass} ${className ?? ''}`.trim()}
      {...props}
    />
  );
};

export default Button;
```

---

## Component CSS (converted from Less)

> Plain CSS equivalent of what the project's `.less` file would contain.
> Rules for conversion:
> - Expand `&` nesting → full selector chains
> - `//` comments → `/* */`
> - No `@variable` — use `var(--token)` only

```css
/* button.css — plain CSS for Figma Make (converted from button.less) */

.comp-button {
  height: var(--size-comp-md);
  border-radius: var(--radius-sm);
  font-size: var(--font-size-xs);
  font-family: var(--font-family-sans);
  line-height: var(--line-height-xs);
  transition:
    background-color var(--duration-fast) var(--easing-default),
    border-color var(--duration-fast) var(--easing-default),
    color var(--duration-fast) var(--easing-default);
}

.comp-button.ant-btn {
  padding: 6px var(--spacing-3);
}

.comp-button-primary.ant-btn-primary {
  background: var(--color-brand-primary);
  border-color: var(--color-brand-primary);
}

.comp-button-primary.ant-btn-primary:hover {
  background: var(--color-brand-primary-hover) !important;
  border-color: var(--color-brand-primary-hover) !important;
}

.comp-button-default.ant-btn-default {
  border-color: var(--color-neutral-border-strong);
  color: var(--color-neutral-text-primary);
}

.comp-button-default.ant-btn-default:hover {
  border-color: var(--color-brand-primary);
  color: var(--color-brand-primary);
}

.comp-button-danger.ant-btn-dangerous {
  color: var(--color-error);
  border-color: var(--color-error);
}

.comp-button-danger.ant-btn-dangerous:hover {
  background: var(--color-error-bg);
}
```

---

## components.md — proprietary library

> Use this extended format when the component library is internal/closed-source.
> AI has no training data on the library — this file IS the API documentation.
> Every component needs a props table and all variant values explained.

```markdown
# Component Reference

> Library: @company/design-system
> Import all components from: `import { ComponentName } from '@company/design-system'`

---

## BcButton

```tsx
import { BcButton } from '@company/design-system'
```

### Props

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| type | `'primary' \| 'secondary' \| 'ghost' \| 'danger' \| 'text'` | `'secondary'` | Visual variant |
| size | `'sm' \| 'md' \| 'lg'` | `'md'` | Component size |
| disabled | `boolean` | `false` | Disabled state |
| loading | `boolean` | `false` | Loading spinner state |
| icon | `ReactNode` | — | Leading icon |
| onClick | `() => void` | — | Click handler |

### Variant meaning

| type value | Visual | When to use |
|------------|--------|-------------|
| `primary` | Filled brand color | Main CTA, one per view |
| `secondary` | Outlined brand color | Secondary actions |
| `ghost` | Text only, no border | Tertiary / inline actions |
| `danger` | Filled red | Destructive actions |
| `text` | Plain text, no chrome | Table row actions |

### Figma mapping

| Figma component | BcButton prop |
|-----------------|---------------|
| Button/Primary | `type="primary"` |
| Button/Secondary | `type="secondary"` |
| Button/Ghost | `type="ghost"` |
| Button/Danger | `type="danger"` |
| Button/Text | `type="text"` |

---

## BcInput

```tsx
import { BcInput } from '@company/design-system'
```

### Props

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| value | `string` | — | Controlled value |
| defaultValue | `string` | — | Uncontrolled default |
| placeholder | `string` | — | Placeholder text |
| disabled | `boolean` | `false` | Disabled state |
| status | `'default' \| 'error' \| 'warning'` | `'default'` | Validation state |
| prefix | `ReactNode` | — | Leading icon/text |
| suffix | `ReactNode` | — | Trailing icon/text |
| onChange | `(value: string) => void` | — | Change handler |

### Figma mapping

| Figma component | BcInput prop |
|-----------------|--------------|
| Input/Default | (no extra props) |
| Input/Error | `status="error"` |
| Input/Disabled | `disabled={true}` |

---

## Composition Rules

- NEVER recreate what BcButton / BcInput / BcTable already provides natively
- ALWAYS import from `@company/design-system`, not from sub-paths
- ThemeProvider is already set up at app root — do not add it inside individual components
```

---

## Component TSX — Proprietary library

> Use this pattern when the component library is internal/closed-source.
> TSX files must be self-documenting: prop comments inline, all variants shown.
> Reason: Figma Make's AI has zero training knowledge of the library.
> These files are the only way to teach the AI the component API.

```tsx
// button.tsx — wrapper for BcButton (proprietary library)
// Teaches Figma Make: import path, prop names, variant values, usage patterns

import { BcButton } from '@company/design-system';
// BcButton props:
//   type: 'primary' | 'secondary' | 'ghost' | 'danger' | 'text'  (default: 'secondary')
//   size: 'sm' | 'md' | 'lg'  (default: 'md')
//   disabled: boolean
//   loading: boolean
//   icon: ReactNode
//   onClick: () => void
import './button.css';

export interface ButtonProps {
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger' | 'text';
  size?: 'sm' | 'md' | 'lg';
  disabled?: boolean;
  loading?: boolean;
  children?: React.ReactNode;
  onClick?: () => void;
}

const Button = ({
  variant = 'secondary',
  size = 'md',
  ...props
}: ButtonProps) => (
  // variant → BcButton.type:
  //   'primary'   = filled brand color, main CTA
  //   'secondary' = outlined, secondary action
  //   'ghost'     = text only, tertiary/inline action
  //   'danger'    = red fill, destructive action
  //   'text'      = plain text, table row action
  <BcButton type={variant} size={size} {...props} />
);

export default Button;

// --- All variant examples (for AI reference) ---
// <Button variant="primary">提交</Button>
// <Button variant="secondary">取消</Button>
// <Button variant="ghost" size="sm">查看详情</Button>
// <Button variant="danger">删除</Button>
// <Button variant="primary" loading>处理中...</Button>
// <Button variant="secondary" disabled>不可用</Button>
```
