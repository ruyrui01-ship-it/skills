---
name: figma-make-kit
description: >
  Use when the user wants to generate a structured kit of files from Figma designs:
  token.json, theme.css, guidelines/ (Guidelines.md, tokens.md, components.md, setup.md),
  and component TSX + CSS files.
  Triggers on intent — the user does NOT need to provide frontend standards upfront;
  the skill will look for them in the local directory or ask.
  Trigger signals: any Figma URL (设计稿/设计规范/典型页面/视觉稿/组件页面 — any form),
  OR output-oriented requests: "提取设计token", "生成token.json/theme.css",
  "生成guidelines", "生成组件代码", "让Figma Make按规范生成代码", "生成设计系统Kit".
  Requires Figma MCP server connection.
---

# Figma Make Kit Generator

Generate a complete override kit so Figma Make's AI produces code that matches
the user's real design system, not its defaults.

## Overview

```
Step 1 → Understand frontend standards (+ proprietary library detection)
Step 2 → Extract design tokens → token.json + theme.css
Step 3 → Generate guidelines/ documents
Step 4 → Generate UI component TSX files
Step 5 → Validate output
Step 6 → Upload to Figma Make (file mapping + merge instructions)
```

## Output Structure

> `output/` is a **local staging directory only**.
> When uploading to Figma Make, upload the **contents** of `output/` — not the folder itself.
> See Step 6 for the complete upload mapping and what to replace vs. what to create as new.

```
output/                              → Figma Make project
├── guidelines/
│   ├── Guidelines.md                → guidelines/Guidelines.md    (replace)
│   ├── tokens.md                    → guidelines/tokens.md        (new file)
│   ├── components.md                → guidelines/components.md    (new file)
│   ├── setup.md                     → guidelines/setup.md         (new file)
│   └── styles.md                    → guidelines/styles.md        (new file)
├── src/
│   ├── styles/
│   │   ├── theme.css                → src/styles/theme.css        (replace)
│   │   └── theme.config.ts          → src/styles/theme.config.ts  (new, antd v5 only)
│   └── app/components/ui/
│       ├── button.tsx               → src/app/components/ui/      (replace or new)
│       ├── button.css               → src/app/components/ui/      (replace or new)
│       └── ...
└── token.json                       → token.json                  (new file)
```
└── theme.config.ts     ← ConfigProvider token map (antd v5 only)
token.json              ← W3C Design Token format
src/app/components/ui/  ← Component TSX + CSS files
```

---

## Step 1: Understand Frontend Standards

Run this step first, before requesting any Figma URL.

### Standards source resolution (try in order, stop at first match)

**Source 1 — User explicitly provides a document or link**
User pastes text, shares a file path, or provides a URL (`.md`, `.mdr`, wiki, internal doc, etc.).
→ Read it directly and extract standards.

**Source 2 — Proactively scan the local working directory**
Before asking the user anything, check the current directory for standards files:
```
Glob patterns to try (in order):
  **/STANDARDS.md, **/standards.md
  **/FRONTEND.md, **/frontend*.md
  **/CONTRIBUTING.md
  **/docs/standards*, **/docs/guidelines*
  **/.cursor/rules, **/.cursorrules
  **/README.md  ← last resort, skim for tech stack section only
```
If a matching file is found: read it, extract standards, tell the user what was found.
If multiple files found: read the most specific one (standards > contributing > readme).

**Source 3 — Ask the user**
Only if Sources 1 and 2 both yield nothing.
Send a single message with all questions at once.
→ Read `references/standards-questions.md` for the exact question set.

### What to extract from whichever source

- Component library and version
- Style approach (CSS Modules / Tailwind / styled-components / other)
- File naming convention (PascalCase vs kebab-case)
- Directory structure for components
- Build tool (for setup.md)

**Minimum required before Step 2:**
- Component library + version (determines token injection method and TSX patterns)
- Style approach (determines how CSS overrides are written)

Infer reasonable defaults when the user says "standard setup" or similar (e.g., "standard antd" → assume antd v5).

### Proprietary library detection

After reading the standards, check if the component library is in the known list:
**Known**: antd, MUI, shadcn/ui, Chakra UI, Radix UI, Headless UI, Mantine, Next UI

If NOT in known list → treat as **proprietary/internal library**.
Follow the proprietary path in `references/standards-questions.md` (Proprietary Library Detection section) before proceeding to Step 2.

**What changes downstream for proprietary libraries:**
- Step 3 → `components.md` becomes a full API reference (props table per component)
- Step 4 → TSX example files must be self-documenting (props commented inline, all variants shown)
- Step 3 setup.md → must describe the actual ThemeProvider, not assume ConfigProvider

---

## Step 2: Extract Design Values → token.json + theme.css

Requires: Figma file URL. Ask for it if not yet provided.

### 2a: Detect available token source

Call `get_variable_defs` with fileKey and root nodeId `0:1`.

- **Variables found** → Path A (preferred)
- **No variables / empty result** → Path B (fallback)

> Note: `get_variable_defs` is a direct MCP tool call. Do NOT route it through `use_figma`.
> Only invoke the `figma-use` skill when you need to call `use_figma` (write operations or JS execution).

### Path A: Extract from Figma variables

1. Map variables to `token.json` grouped by category: `color`, `typography`, `spacing`, `radius`, `shadow`, `motion`
   - W3C format: `{ "$value": "...", "$type": "..." }`
2. Generate `src/styles/theme.css` — one CSS custom property per variable

### Path B: Infer tokens from typical pages

Use when the Figma file has no variable system (values are hardcoded on components).

1. Ask the user for node links to 2–3 representative typical pages (e.g. dashboard, form page, detail page)
2. Call `get_design_context` on each node
3. Collect all unique values across pages: fill/stroke colors, font sizes, font weights, padding/gap, border-radius
4. Infer token names by frequency and semantic role:
   - Values used 3+ times → candidate tokens
   - Most-used interactive fill → `--color-brand-primary`
   - Most-used background → `--color-neutral-bg`
   - Repeated font sizes → `--font-size-sm/md/lg/xl`
   - Repeated gap/padding → `--spacing-1/2/4/6`
5. Confirm inferred token names with the user (brief summary only) before generating files
6. Generate `token.json` and `src/styles/theme.css` from confirmed values

**Ambiguity rule for Path B**: if two similar values exist (e.g., two close blues), flag them and ask the user to clarify semantic intent before naming.

### Common rules (both paths)

- Use HEX in theme.css — do NOT convert to oklch (breaks antd ConfigProvider, MUI createTheme)
- If antd v5: also generate `src/styles/theme.config.ts` with `ConfigProvider` token mapping
- If antd v4: add Less variable override equivalents as comments in theme.css
- If MUI: add `createTheme()` mapping as comments in theme.css

→ Read `references/output-templates.md` for exact file format examples.

---

## Step 3: Generate guidelines/ Documents

Use `figma-create-design-system-rules` skill to generate the skeleton from Figma,
then enrich every section with the user's standards (Step 1) and extracted token names (Step 2).

### Guidelines.md must include:
- Component library rule: use X, NEVER Y
- Style rule: use user's style approach, NEVER inline / hardcoded
- Token rule: use CSS variables from `src/styles/theme.css`, never hardcode values
- File naming and directory conventions from Step 1
- Links to all sub-files: `[tokens.md](tokens.md)`, `[components.md](components.md)`, `[setup.md](setup.md)`

### tokens.md must include per category:
- Token table: `token name | value | usage context`
- DO / NEVER code examples (CSS)
- Special handling notes (unitless values, shadow shorthand)

### components.md

**Known library**: Figma component name → framework component mapping table + key props + composition rules.

**Proprietary library**: extend into a full API reference —
- One section per component with a full props table (name / type / default / description)
- Import path for each component
- All variant values with their visual meaning explained
- Mark any inferred props with `[inferred]` if source was unavailable

### setup.md must include:
- Install command for the component library
- theme.css import location (app entry point)
- ConfigProvider / ThemeProvider setup code with full example
- Style file naming and import pattern

### styles.md must include:
- CSS entry point location (`src/styles/index.css`) and import rule
- Token usage rule (`var(--token)` only, never hardcode)
- Component style file convention (plain `.css`, one per component, imported in `.tsx`)
- NEVER rules (inline styles, hardcoded values, oklch format)

→ See Step 6 for the exact `styles.md` template.
→ Read `references/output-templates.md` for other document structure examples.

---

## Step 4: Generate Component TSX Files

Use `figma-implement-design` skill for each component batch.

### Batching strategy

Do NOT request all component pages at once. Ask for 3–5 related components per batch. Confirm before requesting the next batch.

Default batch order:
1. Basic actions: `button`, `link`
2. Form inputs: `input`, `select`, `checkbox`, `radio-group`, `switch`
3. Navigation: `navigation-menu`, `tabs`, `breadcrumb`, `pagination`
4. Data display: `table`, `card`, `badge`, `avatar`
5. Feedback: `dialog`, `drawer`, `alert`, `sonner`, `progress`

Infer batches from the user's Figma page naming if it differs.

### Per-component generation (standard path)

1. Call `get_design_context` for the component's node link
2. Map Figma component → framework component (from components.md)
3. Write `.tsx` file using the user's naming convention from Step 1
4. Write style file — format depends on the project's style approach (see Style file format below)

### Per-component generation (proprietary library path)

Same as standard, plus: TSX files must be **self-documenting**:
- Comment all prop enum values inline (what each value does visually)
- Show all major variants at the bottom as commented usage examples
- Reason: Figma Make's AI has zero training data on the library — the file IS the API documentation

→ See `references/output-templates.md` — "Component TSX — Proprietary library" for the full pattern.

### Style file format by project stack

**CSS Modules stack (Figma Make default / vanilla / Tailwind):**
- File: `button.module.css`
- Import: `import styles from './button.module.css'`
- Class refs in tsx: `className={styles.primary}`

**Less stack (e.g. antd + BEM):**
- File: `button.css` — write as **plain CSS** (Figma Make only accepts `.css`, not `.less`)
- Convert all Less-specific syntax before writing:
  - Expand `&` nesting → full selector chains (`.comp-button.ant-btn-primary:hover { }`)
  - Replace `//` comments → `/* */`
  - Do NOT use Less variables (`@xxx`) — CSS variables (`var(--xxx)`) only
- Import: `import './button.css'`
- Class refs in tsx: `className="comp-button comp-button-primary"` (BEM strings, not module keys)

> **Why plain CSS?** Figma Make only accepts `.md`, `.css`, and `.tsx`. Less files are ignored.
> Plain CSS with `var()` tokens is functionally equivalent for Figma Make's AI reading context.

### File naming for Figma Make drop-in replacement

- Output path: `src/app/components/ui/`
- TSX filename: kebab-case (`button.tsx`, not `Button.tsx`) — matches Figma Make defaults
- CSS file: same stem + `.css` → `button.css` (regardless of whether the real project uses Less)
- Export name: PascalCase (`export default Button`) — file stays lowercase

→ Read `references/figma-make-filenames.md` for the complete list of Figma Make default filenames.
When a design component maps to a default filename, use the exact name so replacement works without path changes.

**Prohibited in all component files:**
- No hardcoded color / spacing / radius values — CSS variables only
- No inline styles (`style={{}}`)
- No recreating what the component library already provides
- No Less syntax in `.css` files (no `&` nesting, no `@variables`, no `//` comments)

---

## Step 5: Validate Output

### Common checks (all projects)
- [ ] `Guidelines.md` links to `tokens.md`, `components.md`, `setup.md`, `styles.md`
- [ ] `styles.md` generated in `guidelines/` (Figma Make reads this alongside Guidelines.md)
- [ ] All CSS variables in `theme.css` have matching entries in `token.json`
- [ ] No hardcoded values in any component `.tsx` or `.css` file
- [ ] No Less syntax in `.css` files (no `&` nesting, no `@variables`, no `//` comments)
- [ ] Component filenames match the user's naming convention and Figma Make defaults
- [ ] CSS import paths match actual filenames (`.css` not `.less` or `.module.css`)
- [ ] `ConfigProvider` / `ThemeProvider` documented in `setup.md` (if applicable)
- [ ] `theme.config.ts` generated and referenced from `setup.md` (antd v5 only)
- [ ] No unused imports in any `.tsx` file (Vite strict mode will warn / fail)
- [ ] Upload instructions reviewed: `theme.css` merges into `index.css`, not a separate file

### Additional checks for proprietary libraries
- [ ] Every component in `components.md` has a props table with type / default / description
- [ ] All `[inferred]` props are flagged with a warning note for user to verify
- [ ] TSX example files contain inline prop comments and usage examples at the bottom
- [ ] `setup.md` documents the actual ThemeProvider (not ConfigProvider) with import path

---

## Step 6: Upload to Figma Make

### What to upload

Upload the **contents** of `output/` to the Figma Make project root — not the `output/` folder itself.

### Figma Make initial file structure (for reference)

```
guidelines/
└── Guidelines.md          ← only this exists by default
src/
  app/
    components/
      figma/               ← Figma Make's own generated components (never touch)
      ui/                  ← our override components go here
    App.tsx
  styles/
    fonts.css
    index.css
    tailwind.css
    theme.css              ← already exists, we REPLACE this
ATTRIBUTIONS.md
package.json
postcss.config.mjs
vite.config.ts
```

### File-by-file mapping

| Local output file | Action | Target path in Figma Make |
|-------------------|--------|---------------------------|
| `guidelines/Guidelines.md` | **Replace** | `guidelines/Guidelines.md` |
| `guidelines/tokens.md` | **New file** | `guidelines/tokens.md` |
| `guidelines/components.md` | **New file** | `guidelines/components.md` |
| `guidelines/setup.md` | **New file** | `guidelines/setup.md` |
| `guidelines/styles.md` | **New file** | `guidelines/styles.md` |
| `src/styles/theme.css` | **Replace** | `src/styles/theme.css` |
| `src/app/components/ui/*.tsx` | **Replace or new** | `src/app/components/ui/` |
| `src/app/components/ui/*.css` | **Replace or new** | `src/app/components/ui/` |
| `token.json` | **New file** | `token.json` |
| `src/styles/theme.config.ts` | **New file** | `src/styles/theme.config.ts` (antd v5 only) |

### Files to NEVER touch

| File | Reason |
|------|--------|
| `src/app/components/figma/` | Figma Make's own generated components — overwriting breaks regeneration |
| `src/styles/fonts.css` | Font loading, required by Figma Make runtime |
| `src/styles/index.css` | Tailwind + font imports entry, do not modify |
| `src/styles/tailwind.css` | Tailwind config, required by Figma Make runtime |
| `src/app/App.tsx` | App entry point |
| `src/app/components/ui/utils.ts` | Shared `cn()` utility |
| `src/app/components/ui/use-mobile.ts` | Shared hook |

### How theme.css works in Figma Make

`src/styles/theme.css` already exists in every Figma Make project and is imported by `index.css`.
Simply **replace its contents** with our generated token variables — no merge needed, no import path changes.

---

## Compatibility Gap Handling

> **Core principle**: The kit is a translation layer between the team's real standards and what Figma Make accepts.
> Kit files must satisfy Figma Make's format requirements (React 18 + Vite + `.tsx`/`.css`/`.md` only).
> `Guidelines.md` teaches Figma Make to *generate* code that matches the team's actual conventions.
> These are two separate concerns — never conflate them.

```
Team standard  ──[translate]──→  Kit file format  ← Figma Make reads
      ↑                                ↓
      └──── Guidelines.md tells Figma Make what to generate ────┘
```

### Type 1 — Format conflicts (translate in kit, document in Guidelines.md)

| Team standard | Kit translation | Guidelines.md instruction |
|---------------|-----------------|---------------------------|
| Less / Sass | Expand nesting to plain CSS, `//` → `/* */`, no `@var` | "Style files are `.less`. Figma Make generates `.css`; developer converts to `.less` post-generation." |
| styled-components / emotion | Extract token values → `theme.css` CSS vars; write component as plain CSS Module | "This project uses styled-components. Use `styled.div` with `${({ theme }) => theme.tokens.xxx}` syntax." |
| CSS-in-JS zero-runtime (vanilla-extract, linaria) | Write as CSS Module in kit | Document the actual import and usage pattern in `setup.md` |
| Sass / SCSS | Same as Less: flatten to plain CSS | Same as Less row |

### Type 2 — Syntax conflicts (write compatible form in kit, note delta in Guidelines.md)

| Team standard | Kit form | Guidelines.md / setup.md note |
|---------------|----------|-------------------------------|
| Class components | Write as function component | "Team uses class components; Figma Make generates functional — developer refactors if needed." |
| CommonJS (`require`) | Use `import`/`export` in kit | No note needed — ESM is the migration direction |
| Webpack / TS path aliases (`@/components`) | Use relative paths in kit | Document alias setup in `setup.md` under "Vite / tsconfig config" |
| Monorepo internal packages (`@myorg/ui`) | Import from npm equivalent or inline mock | Note actual import in `setup.md` |

### Type 3 — Framework conflicts (Figma Make is React-only)

| Situation | Action |
|-----------|--------|
| Vue / Nuxt | Kit not applicable. Use `figma-implement-design` skill directly (no kit upload). |
| Angular | Same as Vue. |
| 微信小程序 / React Native | Kit targets web React only. Inform user of scope boundary. |
| No React at all | Kit not applicable. Suggest manual guidelines doc or other Figma plugins. |

### Decision flow

```
Conflict detected
│
├─ File format? (.less, .scss, CSS-in-JS)
│        └─ Translate to plain CSS in kit; document real format in Guidelines.md
│
├─ Syntax? (class components, CJS, path aliases)
│        └─ Write kit in compatible syntax; note delta in Guidelines.md / setup.md
│
└─ Framework? (non-React)
         └─ Kit not applicable; recommend alternative path
```

---

## Conditional Paths

| Situation | Action |
|-----------|--------|
| No Figma URL yet | Complete Step 1, then ask for URL |
| No variables in Figma file | Step 2 Path B |
| Ambiguous values in Path B | Ask user to clarify semantic intent before naming |
| User only wants guidelines | Skip Steps 2 and 4 |
| User only wants tokens | Skip Steps 3 and 4 |
| User only wants components | Run Steps 1 and 4; generate minimal `tokens.md` for reference |
| Figma Make regenerated a component | Re-replace only the `.tsx` file; `.css` is never overwritten by Figma Make |
| Format conflict (Less / Sass / CSS-in-JS) | See Compatibility Gap — Type 1 |
| Syntax conflict (class components / aliases) | See Compatibility Gap — Type 2 |
| Framework conflict (Vue / Angular) | See Compatibility Gap — Type 3 |
| Proprietary / internal component library | Step 1 proprietary path; components.md as full API ref; self-documenting TSX |
| No component library (vanilla CSS) | Step 4: plain React + CSS Modules; skip ThemeProvider in `setup.md` |
| Tailwind stack | Token injection via `@layer base`; note potential conflict with Tailwind v4 oklch |
| Next.js | Add server/client component boundary notes in `setup.md` |
